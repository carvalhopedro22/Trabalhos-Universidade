#ifndef _MENU_H_
#define _MENU_H_

#include "Matriz.h"

void menu();
void opcoes(int* opcao);
void opcoes2(int* opcao);
void escreverArquivo(Matriz matriz, Pilha* pilha);

#endif