#include "Matriz.h"

// Alocando posicoes da matriz
void alocarMatriz(int ***matrizTAD, Matriz matriz){
    *matrizTAD = (int**)malloc(matriz.linhas*(sizeof(int*))); // Alocando linhas do tipo ponteiro

    for(int i=0; i<matriz.linhas; i++){
        (*matrizTAD)[i] = (int*)malloc(matriz.colunas*(sizeof(int))); // Alocando colunas do tipo inteiro
    }
}

//Preenchendo a matriz Labirinto. Aqui são usados os dados do arquivo.
void preencherMatrizLabirinto(FILE *arq, Matriz* labirinto){
    char texto[100];

    // Ler linhas
    for(int i=0;i<labirinto->linhas;i++){
        fgets(texto, 100, arq);
        if(i < labirinto->linhas-1)
            texto[strlen(texto)-1] = '\0';
        else
            texto[strlen(texto)] = '\0';

        // Quebrar linhas em partes de strings
        char *piece = strtok(texto, " ");
        int contColuna = 0;
        while(piece!=NULL){
            
            // Comparar strings com I e F
            if(!strcmp(piece, "F")){
                piece = "X";
                labirinto->linhaFinal = i;
                labirinto->colunaFinal = contColuna;
            }
            if(!strcmp(piece, "I")){
                piece = "X";
                labirinto->linhaInicial = i;
                labirinto->colunaInicial = contColuna;
            }
            
            // Converter valores de string para int e
            // atribuir valores a posicoes na matriz
            labirinto->labirinto[i][contColuna] = atoi(piece);
            piece = strtok(NULL, " ");
            contColuna++;
        }
    }
}

// Liberando a matriz
void desalocarMatriz(int **matriz, int linhas) {
  for (int i = 0; i < linhas; i++) {
    free(matriz[i]);
  }
  free(matriz);
}

// Mostrar matriz
void mostrarMatriz(Matriz matriz, int **matrizEscolhida){
    printf("\n");
    for(int i =0; i<matriz.linhas; i++){
        for(int j=0; j<matriz.colunas;j++){
            printf("%d ", matrizEscolhida[i][j]);
        }
        printf("\n");
    }
}

int verificarCaminho(Matriz matriz, int linha, int coluna){
    // se o passo nao ultrapassa os limites da matriz
    if(linha< matriz.linhas && coluna < matriz.colunas) 
        return 1;
    // se o passo for alem dos limites da matriz
    return 0;
}

int movimenta_estudante(Matriz *matriz){ 
    int posicaoBaixo, posicaoDireita;
    int descer, direita;

    // Preenche a matriz de somas com os valores iniciais de cada posicao do labirinto
    for(int i= 0; i<matriz->linhas;i++){
        for(int j= 0;j<matriz->colunas;j++){
            matriz->matrizSomas[i][j] = matriz->labirinto[i][j];
        }
    }

    // Adicionar valor de vida ao ponto inicial do estudante
    matriz->matrizSomas[matriz->linhaInicial][matriz->colunaInicial] = matriz->valorVida;

    // Percorre a matriz da posicao inicial a final do estudante
    for(int linhaAtual = matriz->linhas-1; linhaAtual>=0;linhaAtual--){
        for(int colunaAtual = matriz->colunas-1; colunaAtual>=0;colunaAtual--){
            posicaoBaixo = verificarCaminho(*matriz, linhaAtual+1, colunaAtual);
            posicaoDireita = verificarCaminho(*matriz, linhaAtual, colunaAtual+1);
            // Caso os dois movimentos sejam possiveis
            if(posicaoBaixo==1 && posicaoDireita==1){
                descer = matriz->matrizSomas[linhaAtual+1][colunaAtual]+matriz->matrizSomas[linhaAtual][colunaAtual];            
                direita = matriz->matrizSomas[linhaAtual][colunaAtual+1]+matriz->matrizSomas[linhaAtual][colunaAtual];
                if(descer>direita)
                    matriz->matrizSomas[linhaAtual][colunaAtual] += matriz->matrizSomas[linhaAtual+1][colunaAtual];
                else 
                    matriz->matrizSomas[linhaAtual][colunaAtual] += matriz->matrizSomas[linhaAtual][colunaAtual+1];
            }
            // Caso nao seja possivel ir para a direita mas seja possivel ir para baixo
            else if(posicaoBaixo==1 && posicaoDireita==0)
                matriz->matrizSomas[linhaAtual][colunaAtual] += matriz->matrizSomas[linhaAtual+1][colunaAtual];
            // Caso nao seja possivel ir para baixo mas seja possivel ir para direita
            else if(posicaoBaixo==0 && posicaoDireita==1)
                matriz->matrizSomas[linhaAtual][colunaAtual] += matriz->matrizSomas[linhaAtual][colunaAtual+1];
        }
    }
    return matriz->matrizSomas[matriz->linhaFinal][matriz->colunaFinal];
}

void inserirPassosPilha(Matriz *matriz, Pilha** pilha){
    int linha, coluna;
    int descer, direita;
    int** matrizPercurso;

    alocarMatriz(&matrizPercurso, (*matriz));
    for(linha = 0 ; linha < matriz->linhas ; linha++) 
        for(coluna = 0 ; coluna < matriz->colunas; coluna++)
            matrizPercurso[linha][coluna] = 0;


    for(linha = 1 ; linha < matriz->linhas ; linha++){
        for(coluna = 1 ; coluna < matriz->colunas; coluna++){       
        descer = matriz->matrizSomas[linha-1][coluna]; 
        direita  = matriz->matrizSomas[linha][coluna-1];  
        if(descer > direita) matrizPercurso[linha-1][coluna] = 1;   
        else matrizPercurso[linha][coluna-1] = 1; 
        } 
    }   

    for(linha = 0; linha < matriz->linhas; linha++){
        for(coluna = 0; coluna < matriz->colunas; coluna++){
            if(matrizPercurso[linha][coluna] ==1 ){ 
                inserirPilha(&(*pilha), linha+1, coluna+1);
            }
        }
    }
}

