//foi desmarcado a opção resizable para o tamanho do formulário permanecer fixo.
package trabalhopratico;
import Dados.DadosClientes;
import Dados.DadosProdutos;
import Dados.DadosUsuarios;
import Dados.DadosVendas;
import Formularios.FrmLogin;

public class TrabalhoPratico {
    public static void main(String[] args) {
        DadosUsuarios du = new DadosUsuarios();
        DadosProdutos dp = new DadosProdutos();
        DadosClientes dc = new DadosClientes();
        DadosVendas dv = new DadosVendas();
        
        FrmLogin Login = new FrmLogin();
        Login.setDadosUsuarios(du);
        Login.setDadosProdutos(dp);
        Login.setDadosClientes(dc);
        Login.setDadosVendas(dv);
        Login.setLocationRelativeTo(null); //abre o formulário no centro da tela
        Login.setVisible(true); //queremos o formulário visível.
    }  
}