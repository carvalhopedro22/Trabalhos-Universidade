package Formularios;

import Dados.DadosProdutos;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import Construtivos.Produtos;

public class FrmProdutos extends javax.swing.JInternalFrame {
    private DadosProdutos dp;
    private int produtoatual = 0;
    private boolean cmdNovo = false;
    private DefaultTableModel Usertable;
    
    public void setDadosProdutos(DadosProdutos dp){
        this.dp = dp;
    }
    
    public FrmProdutos() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField1 = new javax.swing.JPasswordField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtcodigoproduto = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtnome = new javax.swing.JTextField();
        cmdproximo = new javax.swing.JButton();
        cmdanterior = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        cmdnovo = new javax.swing.JButton();
        cmdsalvar = new javax.swing.JButton();
        cmdpesquisar = new javax.swing.JButton();
        cmdalterar = new javax.swing.JButton();
        cmdcancelar = new javax.swing.JButton();
        cmddeletar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        Mtable = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        txtpreco = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtcat = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtdesc = new javax.swing.JTextArea();
        txtqtd = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        jPasswordField1.setText("jPasswordField1");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setBackground(new java.awt.Color(255, 255, 255));
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Cadastro de Produtos");
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 0, 255));
        jLabel1.setText("Código Produto:");

        txtcodigoproduto.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtcodigoproduto.setEnabled(false);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setText("Preço:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setText("Nome:");

        txtnome.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtnome.setEnabled(false);

        cmdproximo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/proximo.png"))); // NOI18N
        cmdproximo.setToolTipText("Próximo cadastro");
        cmdproximo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdproximoActionPerformed(evt);
            }
        });

        cmdanterior.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/anterior.png"))); // NOI18N
        cmdanterior.setToolTipText("Cadastro anterior");
        cmdanterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdanteriorActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Faça o Cadastro do Produto aqui");
        jLabel7.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(0, 0, 255)));

        cmdnovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/mais.png"))); // NOI18N
        cmdnovo.setToolTipText("Novo Cadastro");
        cmdnovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdnovoActionPerformed(evt);
            }
        });

        cmdsalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/pasta.png"))); // NOI18N
        cmdsalvar.setToolTipText("Salvar Cadastro");
        cmdsalvar.setEnabled(false);
        cmdsalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdsalvarActionPerformed(evt);
            }
        });

        cmdpesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/pesquisa.png"))); // NOI18N
        cmdpesquisar.setToolTipText("Pesquisar Cadastro");
        cmdpesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdpesquisarActionPerformed(evt);
            }
        });

        cmdalterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/lapis.png"))); // NOI18N
        cmdalterar.setToolTipText("Editar Cadastro");
        cmdalterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdalterarActionPerformed(evt);
            }
        });

        cmdcancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/deletar.png"))); // NOI18N
        cmdcancelar.setToolTipText("Cancelar Cadastro");
        cmdcancelar.setEnabled(false);
        cmdcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdcancelarActionPerformed(evt);
            }
        });

        cmddeletar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/lixeira.png"))); // NOI18N
        cmddeletar.setToolTipText("Deletar Cadastro");
        cmddeletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmddeletarActionPerformed(evt);
            }
        });

        Mtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(Mtable);

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 255));
        jLabel16.setText("Descrição:");

        txtpreco.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtpreco.setEnabled(false);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setText("Estoque Quantidade:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setText("Categoria:");

        txtcat.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtcat.setEnabled(false);

        txtdesc.setColumns(20);
        txtdesc.setRows(5);
        txtdesc.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtdesc.setEnabled(false);
        jScrollPane3.setViewportView(txtdesc);

        txtqtd.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtqtd.setEnabled(false);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/dvd.png"))); // NOI18N

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/cd.png"))); // NOI18N

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/jogos.png"))); // NOI18N

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/livros.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(txtcodigoproduto, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addGap(7, 7, 7)
                        .addComponent(txtpreco, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtnome)
                    .addComponent(jScrollPane3))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtqtd, javax.swing.GroupLayout.DEFAULT_SIZE, 102, Short.MAX_VALUE)
                    .addComponent(txtcat))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addGap(68, 68, 68))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(cmdanterior, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmdproximo, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(95, 95, 95)
                        .addComponent(cmdnovo, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmdalterar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmdcancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmdsalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmdpesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmddeletar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(183, 183, 183)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtcodigoproduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(txtpreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtnome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(txtqtd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addComponent(jLabel16))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(txtcat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel10)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel11)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(cmddeletar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(cmdcancelar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdanterior, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdproximo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdnovo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdalterar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdpesquisar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdsalvar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmdpesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdpesquisarActionPerformed
        // Código do botão de pesquisa
        String produto = JOptionPane.showInputDialog
                                ("Favor digitar o código do produto procurado");
        if(produto.equals("")){
            return;
        }
        int posL = dp.LinhaProduto(produto);
        if(posL == -1){
            JOptionPane.showMessageDialog
                          (rootPane, "Não foi possível localizar este produto");
            return;
        }
        produtoatual = posL;
        visualizarCadastro();
        
    }//GEN-LAST:event_cmdpesquisarActionPerformed

    private void cmdnovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdnovoActionPerformed
        //Código do botão de novo cadastro
        //ao clicar para novo cadastro os botões(primeiro, ultimo, prox, ant) são desabilitados 
        cmdanterior.setEnabled(false);
        cmdproximo.setEnabled(false);
        cmdnovo.setEnabled(false);
        cmdalterar.setEnabled(false);
        cmdcancelar.setEnabled(true); //caso queira cancelar, tem que ficar ativo
        cmdsalvar.setEnabled(true); //deixa ativo para salvar o cadastro
        cmdpesquisar.setEnabled(false);   
        
        //Aqui estamos habilitando os campos para poder escrever
        txtcodigoproduto.setEnabled(true);
        txtnome.setEnabled(true);
        txtdesc.setEnabled(true);
        txtpreco.setEnabled(true);
        txtqtd.setEnabled(true);
        txtcat.setEnabled(true);
           
        //Permitir a escrita após habilitados os campos
        txtcodigoproduto.setText("");
        txtnome.setText("");
        txtdesc.setText("");
        txtpreco.setText("");
        txtqtd.setText("");
        txtcat.setText("");
        
        cmdNovo = true;        
        txtcodigoproduto.requestFocusInWindow();
        CarregarTable();       
    }//GEN-LAST:event_cmdnovoActionPerformed

    private void cmdsalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdsalvarActionPerformed
        //Validando Campos no formulário de cadastro
        if(txtcodigoproduto.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR DIGITAR O CÓDIGO PARA REALIZAR O CADASTRO DO PRODUTO");
            txtcodigoproduto.requestFocusInWindow();
            return;
        }
        if(txtnome.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O NOME DO PRODUTO PARA REALIZAR O CADASTRO");
            txtnome.requestFocusInWindow();
            return;
        }
        
        if(txtdesc.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR A DESCRIÇÃO DO PRODUTO PARA REALIZAR SEU CADASTRO");
            txtdesc.requestFocusInWindow();
            return;
        }

        if(txtpreco.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O PREÇO DO PRODUTO PARA REALIZAR SEU CADASTRO");
            txtpreco.requestFocusInWindow();
            return;
        }

        if(txtqtd.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR A QUANTIDADE EM ESTOQUE PARA REALIZAR SEU CADASTRO");
            txtqtd.requestFocusInWindow();
            return;
        }
        
        if(txtcat.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR A CATEGORIA PARA REALIZAR SEU CADASTRO");
            txtcat.requestFocusInWindow();
            return;
        }

        int poslinha = dp.LinhaProduto(txtcodigoproduto.getText());
        if(cmdNovo){
            if(poslinha != -1){ //produto já existe
                txtcodigoproduto.requestFocusInWindow();
                return;
            }
        }else{
            if(poslinha == 1){ //produto não cadastrado ainda
                txtcodigoproduto.requestFocusInWindow(); 
                return;
            }
        }
        
        Produtos MProdutos = new Produtos(txtcodigoproduto.getText(), 
                                         txtnome.getText(), txtdesc.getText(),
                                         txtpreco.getText(), txtqtd.getText(),
                                         txtcat.getText());
       
        String msg;
        if(cmdNovo){
            msg = dp.CadProduto(MProdutos);    
        }else{
            msg = dp.EditarProduto(MProdutos, poslinha);
        }
        JOptionPane.showMessageDialog(rootPane,msg);
        CarregarTable();
        
        //Código do botão salvar cadastro
        //após ter um cadastro, já é possível que todos os botões estejam ativados 
        cmdanterior.setEnabled(true);
        cmdproximo.setEnabled(true);
        cmdnovo.setEnabled(true);
        cmdalterar.setEnabled(true);
        cmdcancelar.setEnabled(false);
        cmdsalvar.setEnabled(false); 
        cmdpesquisar.setEnabled(true);
        
        txtcodigoproduto.setEnabled(false);
        txtnome.setEnabled(false);
        txtdesc.setEnabled(false);
        txtpreco.setEnabled(false);
        txtqtd.setEnabled(false);
        txtcat.setEnabled(false);

        CarregarTable();
        return;    
    }//GEN-LAST:event_cmdsalvarActionPerformed

    private void cmdcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdcancelarActionPerformed
        //Código do botão cancelar cadastro
        cmdanterior.setEnabled(true);
        cmdproximo.setEnabled(true);
        cmdnovo.setEnabled(true);
        cmdalterar.setEnabled(true);
        cmdcancelar.setEnabled(false);
        cmdsalvar.setEnabled(false); 
        cmdpesquisar.setEnabled(true);
        
        txtcodigoproduto.setEnabled(false);
        txtnome.setEnabled(false);
        txtdesc.setEnabled(false);
        txtpreco.setEnabled(false);
        txtqtd.setEnabled(false);
        txtcat.setEnabled(false);
    }//GEN-LAST:event_cmdcancelarActionPerformed

    private void cmdalterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdalterarActionPerformed
        // TODO add your handling code here: 
        cmdanterior.setEnabled(false);
        cmdproximo.setEnabled(false);
        cmdnovo.setEnabled(false);
        cmdalterar.setEnabled(false);
        cmdcancelar.setEnabled(true); //caso queira cancelar, tem que ficar ativo
        cmdsalvar.setEnabled(true); //deixa ativo para salvar o cadastro
        cmdpesquisar.setEnabled(false);   
        
        txtcodigoproduto.setEnabled(false);
        txtnome.setEnabled(true);
        txtdesc.setEnabled(true);
        txtpreco.setEnabled(true);
        txtqtd.setEnabled(true);
        txtcat.setEnabled(true);
 
        cmdNovo = false;
        txtnome.requestFocusInWindow();
    }//GEN-LAST:event_cmdalterarActionPerformed

    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened
        visualizarCadastro();
        CarregarTable();
    }//GEN-LAST:event_formInternalFrameOpened

    private void cmdproximoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdproximoActionPerformed
        //Botão do próximo cadastro
        produtoatual++;
        if(produtoatual == dp.NProdutos()){
            produtoatual = 0;
        }
        visualizarCadastro();
    }//GEN-LAST:event_cmdproximoActionPerformed

    private void cmdanteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdanteriorActionPerformed
        //Botão do cadastro anterior
        produtoatual--;
        if(produtoatual == -1){
            produtoatual = dp.NProdutos()-1;
        }     
        visualizarCadastro();
    }//GEN-LAST:event_cmdanteriorActionPerformed

    private void cmddeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmddeletarActionPerformed
        // Código do botão deletar
        int Del = JOptionPane.showConfirmDialog
                              (rootPane, "DESEJA DELETAR ESSE PRODUTO?");
        if(Del != 0){
            return;
        }
        String msg;
        msg = dp.DeletarProduto(produtoatual);
        JOptionPane.showMessageDialog(rootPane,msg);
        
        produtoatual = 0;//excluindo o escolhido ele volta ao primeiro cadastro
        visualizarCadastro();
        CarregarTable();
    }//GEN-LAST:event_cmddeletarActionPerformed
    
    private void visualizarCadastro(){
        txtcodigoproduto.setText(dp.getProdutos()[produtoatual].getCodproduto());
        txtnome.setText(dp.getProdutos()[produtoatual].getNome());
        txtdesc.setText(dp.getProdutos()[produtoatual].getDesc());
        txtpreco.setText("" + dp.getProdutos()[produtoatual].getPreco());
        txtqtd.setText(dp.getProdutos()[produtoatual].getQtd());
        txtcat.setText(dp.getProdutos()[produtoatual].getCategoria());
    }

    private void CarregarTable(){
        String titulocabecalho[] = {"Cod Produto", "Nome", "Descrição", "Preço", "Quantidade", "Categoria"}; //cabeçalho da tabela
        String RegCadastro[] = new String[6];
        Usertable = new DefaultTableModel(null, titulocabecalho);
        for(int i = 0; i < dp.NProdutos(); i++){
            RegCadastro[0] = dp.getProdutos()[i].getCodproduto();
            RegCadastro[1] = dp.getProdutos()[i].getNome();
            RegCadastro[2] = dp.getProdutos()[i].getDesc();
            RegCadastro[3] = "" + dp.getProdutos()[i].getPreco();
            RegCadastro[4] = "" + dp.getProdutos()[i].getQtd();
            RegCadastro[5] = dp.getProdutos()[i].getCategoria();
            
            Usertable.addRow(RegCadastro);
        }
        Mtable.setModel(Usertable);
    }
 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Mtable;
    private javax.swing.JButton cmdalterar;
    private javax.swing.JButton cmdanterior;
    private javax.swing.JButton cmdcancelar;
    private javax.swing.JButton cmddeletar;
    private javax.swing.JButton cmdnovo;
    private javax.swing.JButton cmdpesquisar;
    private javax.swing.JButton cmdproximo;
    private javax.swing.JButton cmdsalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtcat;
    private javax.swing.JTextField txtcodigoproduto;
    private javax.swing.JTextArea txtdesc;
    private javax.swing.JTextField txtnome;
    private javax.swing.JTextField txtpreco;
    private javax.swing.JTextField txtqtd;
    // End of variables declaration//GEN-END:variables
}
