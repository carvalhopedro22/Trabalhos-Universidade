package Formularios;

import Dados.DadosVendas;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import Construtivos.Vendas;
import Uteis.Utilidades;

public class FrmVendas extends javax.swing.JInternalFrame {
    private DadosVendas dv;
    private int vendaAtual = 0;
    private boolean cmdNovo = false;
    private DefaultTableModel Usertable;
    
    public void setDadosVendas(DadosVendas dv){
        this.dv = dv;
    }
    
    public FrmVendas() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField1 = new javax.swing.JPasswordField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtprodutocomprado = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtnomecliente = new javax.swing.JTextField();
        cmdproximo = new javax.swing.JButton();
        cmdanterior = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        cmdnovo = new javax.swing.JButton();
        cmdsalvar = new javax.swing.JButton();
        cmdalterar = new javax.swing.JButton();
        cmdcancelar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        cmddeletar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        Mtable = new javax.swing.JTable();
        txtendereco = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtpreco = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtstatus = new javax.swing.JTextField();
        txtqtd = new javax.swing.JTextField();
        txtdatainicial = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtdatafinal = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txttotalpagar = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtcodigovenda = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();

        jPasswordField1.setText("jPasswordField1");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setBackground(new java.awt.Color(255, 255, 255));
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Venda de Produtos");
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 0, 255));
        jLabel1.setText("Produto Comprado:");

        txtprodutocomprado.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtprodutocomprado.setEnabled(false);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setText("Preço:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setText("Nome do Cliente:");

        txtnomecliente.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtnomecliente.setEnabled(false);

        cmdproximo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/proximo.png"))); // NOI18N
        cmdproximo.setToolTipText("Próximo produto");
        cmdproximo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdproximoActionPerformed(evt);
            }
        });

        cmdanterior.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/anterior.png"))); // NOI18N
        cmdanterior.setToolTipText("Produto Anterior");
        cmdanterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdanteriorActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Faça sua compra aqui");
        jLabel7.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(0, 0, 255)));

        cmdnovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/mais.png"))); // NOI18N
        cmdnovo.setToolTipText("Novo Produto");
        cmdnovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdnovoActionPerformed(evt);
            }
        });

        cmdsalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/pasta.png"))); // NOI18N
        cmdsalvar.setToolTipText("Salvar Venda");
        cmdsalvar.setEnabled(false);
        cmdsalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdsalvarActionPerformed(evt);
            }
        });

        cmdalterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/lapis.png"))); // NOI18N
        cmdalterar.setToolTipText("Editar Venda");
        cmdalterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdalterarActionPerformed(evt);
            }
        });

        cmdcancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/deletar.png"))); // NOI18N
        cmdcancelar.setToolTipText("Cancelar Venda");
        cmdcancelar.setEnabled(false);
        cmdcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdcancelarActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        jLabel8.setText("Data Inicial:");

        cmddeletar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/lixeira.png"))); // NOI18N
        cmddeletar.setToolTipText("Deletar Venda");
        cmddeletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmddeletarActionPerformed(evt);
            }
        });

        Mtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(Mtable);

        txtendereco.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtendereco.setEnabled(false);

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 255));
        jLabel16.setText("Endereço para entrega:");

        txtpreco.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtpreco.setEnabled(false);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setText("Quantidade:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setText("Status:");

        txtstatus.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtstatus.setEnabled(false);

        txtqtd.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtqtd.setEnabled(false);

        txtdatainicial.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtdatainicial.setEnabled(false);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setText("Data Final:");

        txtdatafinal.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtdatafinal.setEnabled(false);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 255));
        jLabel9.setText("Total a pagar:");

        txttotalpagar.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txttotalpagar.setEnabled(false);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 255));
        jLabel10.setText("CodigoVenda:");

        txtcodigovenda.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtcodigovenda.setEnabled(false);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/Vendas2.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel16))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(txtprodutocomprado, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel2)
                                        .addGap(7, 7, 7)
                                        .addComponent(txtpreco, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtendereco, javax.swing.GroupLayout.DEFAULT_SIZE, 271, Short.MAX_VALUE)
                                        .addComponent(txtnomecliente, javax.swing.GroupLayout.Alignment.TRAILING))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(jLabel11)
                                .addGap(81, 81, 81)
                                .addComponent(jLabel9)
                                .addGap(18, 18, 18)
                                .addComponent(txttotalpagar, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(38, 38, 38)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel6)
                                            .addComponent(jLabel8)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel5)
                                                .addGap(6, 6, 6)))
                                        .addGap(23, 23, 23))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(18, 18, 18)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtdatainicial, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtqtd, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtstatus, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtdatafinal, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtcodigovenda, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(cmdanterior, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmdproximo, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(95, 95, 95)
                        .addComponent(cmdnovo, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmdalterar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmdcancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmdsalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmddeletar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(183, 183, 183)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(119, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtprodutocomprado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(txtpreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtcodigovenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtdatainicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtdatafinal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtnomecliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtendereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtqtd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtstatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(txttotalpagar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)))
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(cmddeletar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(cmdcancelar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdanterior, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdproximo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdnovo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdalterar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdsalvar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmdnovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdnovoActionPerformed
        //Código do botão de novo cadastro
        //ao clicar para novo cadastro os botões(primeiro, ultimo, prox, ant) são desabilitados
        cmdanterior.setEnabled(false);
        cmdproximo.setEnabled(false);
        cmdnovo.setEnabled(false);
        cmdalterar.setEnabled(false);
        cmdcancelar.setEnabled(true); //caso queira cancelar, tem que ficar ativo
        cmdsalvar.setEnabled(true); //deixa ativo para salvar o cadastro   
        
        //Aqui estamos habilitando os campos para poder escrever
        txtcodigovenda.setEnabled(true);
        txtprodutocomprado.setEnabled(true);
        txtnomecliente.setEnabled(true);
        txtendereco.setEnabled(true);
        txtpreco.setEnabled(true);
        txtdatainicial.setEnabled(true);
        txtdatafinal.setEnabled(true);
        txtqtd.setEnabled(true);
        txtstatus.setEnabled(true);
        txttotalpagar.setEnabled(true);
        
        //Permitir a escrita após habilitados os campos
        txtcodigovenda.setText("");
        txtprodutocomprado.setText("");
        txtnomecliente.setText("");
        txtendereco.setText("");
        txtpreco.setText("");
        txtdatainicial.setText("");
        txtdatafinal.setText("");
        txtqtd.setText("");
        txtstatus.setText("");
        txttotalpagar.setText("");
        
        cmdNovo = true;        
        txtprodutocomprado.requestFocusInWindow();
        CarregarTable();       
    }//GEN-LAST:event_cmdnovoActionPerformed

    private void cmdsalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdsalvarActionPerformed
        //Validando Campos no formulário de cadastro
        if(txtcodigovenda.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR DIGITAR O CÓDIGO DA VENDA PARA REALIZAR O CADASTRO DA VENDA");
            txtcodigovenda.requestFocusInWindow();
            return;
        }
        
        if(txtprodutocomprado.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR DIGITAR O NOME DO PRODUTO COMPRADO PARA REALIZAR O CADASTRO DA VENDA");
            txtprodutocomprado.requestFocusInWindow();
            return;
        }
        
        if(txtnomecliente.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O NOME DO CLIENTE QUE ESTÁ REALIZANDO A COMPRA PARA REALIZAR O CADASTRO");
            txtnomecliente.requestFocusInWindow();
            return;
        }
        
        if(txtendereco.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O ENDEREÇO DE ENTREGA PARA REALIZAR SEU CADASTRO");
            txtendereco.requestFocusInWindow();
            return;
        }

        if(txtpreco.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O PREÇO DO PRODUTO PARA REALIZAR SEU CADASTRO");
            txtpreco.requestFocusInWindow();
            return;
        }
        
        if(!Utilidades.isNumeric(txtpreco.getText())){ //assumindo que preço só aceite números
            JOptionPane.showMessageDialog(rootPane, "ESTE CAMPO SÓ ACEITA NÚMEROS");
            txtpreco.requestFocusInWindow();
            return;
        }
        
        int preco = Integer.parseInt(txtpreco.getText());
        if(preco <= 0){
            JOptionPane.showMessageDialog(rootPane, "ESTE CAMPO NÃO ACEITA PREÇOS VALENDO 0");
            txtpreco.requestFocusInWindow();
            return;
        }
        
        if(txtdatainicial.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR DIGITAR A DATA INICIAL DA VENDA PARA REALIZAR O CADASTRO");
            txtdatainicial.requestFocusInWindow();
            return;
        }
        
        if(txtdatafinal.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR DIGITAR A DATA FINAL DA VENDA PARA REALIZAR O CADASTRO");
            txtdatafinal.requestFocusInWindow();
            return;
        }
        
        if(txtqtd.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR DIGITAR A QUANTIDADE DE PRODUTOS COMPRADOS PARA REALIZAR O CADASTRO");
            txtqtd.requestFocusInWindow();
            return;
        }
        
        if(txtstatus.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O STATUS DA VENDA PARA REALIZAR SEU CADASTRO");
            txtstatus.requestFocusInWindow();
            return;
        }
        
        if(txttotalpagar.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR DIGITAR O VALOR TOTAL DA COMPRA DO CLIENTE");
            txttotalpagar.requestFocusInWindow();
            return;
        }

        int poslinha = dv.LinhaVenda(txtcodigovenda.getText());
        if(cmdNovo){
            if(poslinha != -1){ //produto já existe
                txtcodigovenda.requestFocusInWindow();
                return;
            }
        }else{
            if(poslinha == 1){ //produto não cadastrado ainda
                txtprodutocomprado.requestFocusInWindow(); 
                return;
            }
        }
        
        Vendas Mvendas = new Vendas(txtcodigovenda.getText(), txtprodutocomprado.getText(), 
                                    txtnomecliente.getText(), txtendereco.getText(),
                                    txtpreco.getText(), txtdatainicial.getText(), txtdatafinal.getText(), 
                                    txtqtd.getText(), txtstatus.getText(), txttotalpagar.getText());
       
        String msg;
        if(cmdNovo){
            msg = dv.CadVendas(Mvendas);   
        }else{
            msg = dv.EditarVenda(Mvendas, poslinha);
        }
        JOptionPane.showMessageDialog(rootPane,msg);
        CarregarTable();
        
        //Código do botão salvar cadastro
        //após ter um cadastro, já é possível que todos os botões estejam ativados 
        cmdanterior.setEnabled(true);
        cmdproximo.setEnabled(true);
        cmdnovo.setEnabled(true);
        cmdalterar.setEnabled(true);
        cmdcancelar.setEnabled(false);
        cmdsalvar.setEnabled(false); 
        
        txtcodigovenda.setEnabled(false);
        txtprodutocomprado.setEnabled(false);
        txtnomecliente.setEnabled(false);
        txtendereco.setEnabled(false);
        txtpreco.setEnabled(false);
        txtdatainicial.setEnabled(false);
        txtdatafinal.setEnabled(false);
        txtqtd.setEnabled(false);
        txtstatus.setEnabled(false);
        txttotalpagar.setEnabled(false);


        CarregarTable();
        return;    
    }//GEN-LAST:event_cmdsalvarActionPerformed

    private void cmdcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdcancelarActionPerformed
        //Código do botão cancelar cadastro 
        cmdanterior.setEnabled(true);
        cmdproximo.setEnabled(true);
        cmdnovo.setEnabled(true);
        cmdalterar.setEnabled(true);
        cmdcancelar.setEnabled(false);
        cmdsalvar.setEnabled(false); 
        
        txtcodigovenda.setEnabled(false);
        txtprodutocomprado.setEnabled(false);
        txtnomecliente.setEnabled(false);
        txtendereco.setEnabled(false);
        txtpreco.setEnabled(false);
        txtdatainicial.setEnabled(false);
        txtdatafinal.setEnabled(false);
        txtqtd.setEnabled(false);
        txtstatus.setEnabled(false);
        txttotalpagar.setEnabled(false);
    }//GEN-LAST:event_cmdcancelarActionPerformed

    private void cmdalterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdalterarActionPerformed
        // TODO add your handling code here: 
        cmdanterior.setEnabled(false);
        cmdproximo.setEnabled(false);
        cmdnovo.setEnabled(false);
        cmdalterar.setEnabled(false);
        cmdcancelar.setEnabled(true); //caso queira cancelar, tem que ficar ativo
        cmdsalvar.setEnabled(true); //deixa ativo para salvar o cadastro  
        
        txtcodigovenda.setEnabled(false);
        txtprodutocomprado.setEnabled(true);
        txtnomecliente.setEnabled(true);
        txtendereco.setEnabled(true);
        txtpreco.setEnabled(true);
        txtdatainicial.setEnabled(true);
        txtdatafinal.setEnabled(true);
        txtqtd.setEnabled(true);
        txtstatus.setEnabled(true);
        txttotalpagar.setEnabled(true);
 
        cmdNovo = false;
        txtnomecliente.requestFocusInWindow();
    }//GEN-LAST:event_cmdalterarActionPerformed

    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened
        visualizarCadastro();
        CarregarTable();
    }//GEN-LAST:event_formInternalFrameOpened

    private void cmdproximoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdproximoActionPerformed
        //Botão do próximo cadastro
        vendaAtual++;
        if(vendaAtual == dv.NVendas()){
            vendaAtual = 0;
        }
        visualizarCadastro();
    }//GEN-LAST:event_cmdproximoActionPerformed

    private void cmdanteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdanteriorActionPerformed
        //Botão do cadastro anterior
        vendaAtual--;
        if(vendaAtual == -1){
            vendaAtual = dv.NVendas()-1;
        }     
        visualizarCadastro();
    }//GEN-LAST:event_cmdanteriorActionPerformed

    private void cmddeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmddeletarActionPerformed
        // Código do botão deletar
        int Del = JOptionPane.showConfirmDialog(rootPane, "DESEJA DELETAR ESSA VENDA?");
        if(Del != 0){
            return;
        }
        String msg;
        msg = dv.DeletarVenda(vendaAtual);
        JOptionPane.showMessageDialog(rootPane,msg);
        
        vendaAtual = 0;//excluindo o escolhido ele volta ao primeiro cadastro
        visualizarCadastro();
        CarregarTable();
    }//GEN-LAST:event_cmddeletarActionPerformed
    
    private void visualizarCadastro(){
        txtcodigovenda.setText(dv.getVendas()[vendaAtual].getCodigovenda());
        txtprodutocomprado.setText(dv.getVendas()[vendaAtual].getProdutoComprado());
        txtnomecliente.setText(dv.getVendas()[vendaAtual].getNomeCliente());
        txtendereco.setText(dv.getVendas()[vendaAtual].getEnderecoEntrega());
        txtpreco.setText(dv.getVendas()[vendaAtual].getPreco());
        txtdatainicial.setText(dv.getVendas()[vendaAtual].getDataInicial());
        txtdatafinal.setText(dv.getVendas()[vendaAtual].getDataFinal());
        txtqtd.setText(dv.getVendas()[vendaAtual].getQtd());
        txtstatus.setText(dv.getVendas()[vendaAtual].getStatus());
        txttotalpagar.setText(dv.getVendas()[vendaAtual].getTotalPagar());
    }

    private void CarregarTable(){
        String titulocabecalho[] = {"Nome do Cliente", "Produto", "Preço", "Quantidade", "Data Inicial", "Data Final", "Total a Pagar"}; //cabeçalho da tabela
        String RegCadastro[] = new String[7];
        Usertable = new DefaultTableModel(null, titulocabecalho);
        for(int i = 0; i < dv.NVendas(); i++){
            RegCadastro[0] = dv.getVendas()[i].getNomeCliente();
            RegCadastro[1] = dv.getVendas()[i].getProdutoComprado();
            RegCadastro[2] = dv.getVendas()[i].getPreco();
            RegCadastro[3] = dv.getVendas()[i].getQtd();
            RegCadastro[4] = dv.getVendas()[i].getDataInicial();
            RegCadastro[5] = dv.getVendas()[i].getDataFinal();
            RegCadastro[6] = dv.getVendas()[i].getTotalPagar();
            
            Usertable.addRow(RegCadastro);
        }
        Mtable.setModel(Usertable);
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Mtable;
    private javax.swing.JButton cmdalterar;
    private javax.swing.JButton cmdanterior;
    private javax.swing.JButton cmdcancelar;
    private javax.swing.JButton cmddeletar;
    private javax.swing.JButton cmdnovo;
    private javax.swing.JButton cmdproximo;
    private javax.swing.JButton cmdsalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtcodigovenda;
    private javax.swing.JTextField txtdatafinal;
    private javax.swing.JTextField txtdatainicial;
    private javax.swing.JTextField txtendereco;
    private javax.swing.JTextField txtnomecliente;
    private javax.swing.JTextField txtpreco;
    private javax.swing.JTextField txtprodutocomprado;
    private javax.swing.JTextField txtqtd;
    private javax.swing.JTextField txtstatus;
    private javax.swing.JTextField txttotalpagar;
    // End of variables declaration//GEN-END:variables
}
