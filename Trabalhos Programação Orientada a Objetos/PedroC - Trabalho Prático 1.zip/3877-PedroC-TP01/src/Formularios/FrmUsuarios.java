package Formularios;

import Dados.DadosUsuarios;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import Construtivos.Usuarios;

public class FrmUsuarios extends javax.swing.JInternalFrame {
    private DadosUsuarios du;
    private int usuarioatual = 0;
    private boolean cmdNovo = false;
    private DefaultTableModel Usertable;
    
    public void setDadosUsuarios(DadosUsuarios du){
        this.du = du;
    }
    
    public FrmUsuarios() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField1 = new javax.swing.JPasswordField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtcodigousuario = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        cmbperfil = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        txtnome = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtsnome = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cmdproximo = new javax.swing.JButton();
        cmdanterior = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        cmdnovo = new javax.swing.JButton();
        cmdsalvar = new javax.swing.JButton();
        cmdpesquisar = new javax.swing.JButton();
        cmdalterar = new javax.swing.JButton();
        cmdcancelar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        txtcpf = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtemail = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtrua = new javax.swing.JTextField();
        txtcompl = new javax.swing.JTextField();
        txtbairro = new javax.swing.JTextField();
        txtcep = new javax.swing.JTextField();
        txtcidade = new javax.swing.JTextField();
        txtsenha = new javax.swing.JPasswordField();
        txtcsenha = new javax.swing.JPasswordField();
        cmddeletar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        Mtable = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();

        jPasswordField1.setText("jPasswordField1");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Cadastro de Usuários");
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 0, 255));
        jLabel1.setText("Código Usuário:");

        txtcodigousuario.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtcodigousuario.setEnabled(false);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setText("Perfil");

        cmbperfil.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione Perfil", "Administrador", "Funcionário" }));
        cmbperfil.setEnabled(false);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setText("Nome:");

        txtnome.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtnome.setEnabled(false);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setText("Sobrenome:");

        txtsnome.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtsnome.setEnabled(false);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setText("Conf. Senha:");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setText("Senha:");

        cmdproximo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/proximo.png"))); // NOI18N
        cmdproximo.setToolTipText("Próximo cadastro");
        cmdproximo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdproximoActionPerformed(evt);
            }
        });

        cmdanterior.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/anterior.png"))); // NOI18N
        cmdanterior.setToolTipText("Cadastro anterior");
        cmdanterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdanteriorActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Faça seu Cadastro aqui");
        jLabel7.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(0, 0, 255)));

        cmdnovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/mais.png"))); // NOI18N
        cmdnovo.setToolTipText("Novo Cadastro");
        cmdnovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdnovoActionPerformed(evt);
            }
        });

        cmdsalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/pasta.png"))); // NOI18N
        cmdsalvar.setToolTipText("Salvar Cadastro");
        cmdsalvar.setEnabled(false);
        cmdsalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdsalvarActionPerformed(evt);
            }
        });

        cmdpesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/pesquisa.png"))); // NOI18N
        cmdpesquisar.setToolTipText("Pesquisar Cadastro");
        cmdpesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdpesquisarActionPerformed(evt);
            }
        });

        cmdalterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/lapis.png"))); // NOI18N
        cmdalterar.setToolTipText("Editar Cadastro");
        cmdalterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdalterarActionPerformed(evt);
            }
        });

        cmdcancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/deletar.png"))); // NOI18N
        cmdcancelar.setToolTipText("Cancelar Cadastro");
        cmdcancelar.setEnabled(false);
        cmdcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdcancelarActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        jLabel8.setText("CPF:");

        txtcpf.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtcpf.setEnabled(false);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 255));
        jLabel9.setText("E-mail:");

        txtemail.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtemail.setEnabled(false);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 0, 0));
        jLabel10.setText("Endereço");

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 0, 0));
        jLabel11.setText("Rua:");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 0, 0));
        jLabel12.setText("Complemento:");
        jLabel12.setToolTipText("");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 0, 0));
        jLabel13.setText("Bairro:");

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 0, 0));
        jLabel14.setText("CEP:");

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 0, 0));
        jLabel15.setText("Cidade:");

        txtrua.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtrua.setEnabled(false);

        txtcompl.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtcompl.setEnabled(false);

        txtbairro.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtbairro.setEnabled(false);

        txtcep.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtcep.setEnabled(false);

        txtcidade.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtcidade.setEnabled(false);

        txtsenha.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtsenha.setEnabled(false);

        txtcsenha.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtcsenha.setEnabled(false);

        cmddeletar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/lixeira.png"))); // NOI18N
        cmddeletar.setToolTipText("Deletar Cadastro");
        cmddeletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmddeletarActionPerformed(evt);
            }
        });

        Mtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(Mtable);

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/administrador.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(256, 256, 256)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(467, 467, 467)
                                .addComponent(jLabel8))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(121, 121, 121)
                                .addComponent(cmdanterior, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cmdproximo, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(95, 95, 95)
                                .addComponent(cmdnovo, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cmdalterar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cmdcancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cmdsalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addComponent(jLabel4))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(8, 8, 8)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel1)
                                                .addComponent(jLabel3)))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addContainerGap()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING)))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtnome, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtcodigousuario, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cmbperfil, 0, 101, Short.MAX_VALUE))
                                    .addComponent(txtsnome)
                                    .addComponent(txtemail)
                                    .addComponent(txtcsenha)
                                    .addComponent(txtsenha))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txtrua, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                                        .addComponent(txtcpf, javax.swing.GroupLayout.Alignment.LEADING))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtcompl)
                                            .addComponent(txtbairro)
                                            .addComponent(txtcep)
                                            .addComponent(txtcidade, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(cmdpesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(cmddeletar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(44, 44, 44)
                                        .addComponent(jLabel16))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(jLabel10)))
                        .addGap(0, 13, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbperfil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(txtcodigousuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel8)
                    .addComponent(txtcpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtnome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtsnome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel11)
                    .addComponent(txtrua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel12)
                    .addComponent(txtcompl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtsenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel5)
                                .addComponent(txtbairro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtcsenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtemail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14)
                            .addComponent(txtcep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtcidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15)))
                    .addComponent(jLabel16))
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(cmddeletar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(cmdcancelar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdanterior, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdproximo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdnovo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdalterar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdpesquisar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdsalvar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(17, 17, 17)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmdpesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdpesquisarActionPerformed
        // Código do botão de pesquisa
        String usuario = JOptionPane.showInputDialog("Favor digitar o código do usuário procurado");
        if(usuario.equals("")){
            return;
        }
        int posL = du.LinhaUsuario(usuario);
        if(posL == -1){
            JOptionPane.showMessageDialog(rootPane, "Não foi possível localizar este usuário");
            return;
        }
        usuarioatual = posL;
        visualizarCadastro();
        
    }//GEN-LAST:event_cmdpesquisarActionPerformed

    private void cmdnovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdnovoActionPerformed
        //Código do botão de novo cadastro
        //ao clicar para novo cadastro os botões(primeiro, ultimo, prox, ant) são desabilitados 
        cmdanterior.setEnabled(false);
        cmdproximo.setEnabled(false);
        cmdnovo.setEnabled(false);
        cmdalterar.setEnabled(false);
        cmdcancelar.setEnabled(true); //caso queira cancelar, tem que ficar ativo
        cmdsalvar.setEnabled(true); //deixa ativo para salvar o cadastro
        cmdpesquisar.setEnabled(false);   
        
        //Aqui estamos habilitando os campos para poder escrever
        txtcodigousuario.setEnabled(true);
        txtnome.setEnabled(true);
        txtsnome.setEnabled(true);
        txtsenha.setEnabled(true);
        txtcsenha.setEnabled(true);
        cmbperfil.setEnabled(true);
        txtemail.setEnabled(true);
        txtcpf.setEnabled(true);
        txtrua.setEnabled(true);
        txtcompl.setEnabled(true);
        txtbairro.setEnabled(true);
        txtcep.setEnabled(true);
        txtcidade.setEnabled(true);
        
        //Permitir a escrita após habilitados os campos
        txtcodigousuario.setText("");
        txtnome.setText("");
        txtsnome.setText("");
        txtsenha.setText("");
        txtcsenha.setText("");
        cmbperfil.setSelectedIndex(0);
        txtemail.setText("");
        txtcpf.setText("");
        txtrua.setText("");
        txtcompl.setText("");
        txtbairro.setText("");
        txtcep.setText("");
        txtcidade.setText("");
        
        cmdNovo = true;
        txtcodigousuario.requestFocusInWindow();
        CarregarTable();
        
    }//GEN-LAST:event_cmdnovoActionPerformed

    private void cmdsalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdsalvarActionPerformed
        //Validando Campos no formulário de cadastro
        if(txtcodigousuario.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR DIGITAR O CÓDIGO PARA REALIZAR SEU CADASTRO");
            txtcodigousuario.requestFocusInWindow();
            return;
        }
        
        if(cmbperfil.getSelectedIndex() == 0){
            JOptionPane.showMessageDialog(rootPane, "FAVOR SELECIONAR UM PERFIL PARA REALIZAR SEU CADASTRO");
            cmbperfil.requestFocusInWindow();
            return;
        }
        
        if(txtnome.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O NOME PARA REALIZAR SEU CADASTRO");
            txtnome.requestFocusInWindow();
            return;
        }
        
        if(txtsnome.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O SOBRENOME PARA REALIZAR SEU CADASTRO");
            txtsnome.requestFocusInWindow();
            return;
        }
        
        String SSenha = new String(txtsenha.getPassword());
        String ConfSenha = new String(txtcsenha.getPassword());
        
        if(SSenha.equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR A SENHA PARA REALIZAR SEU CADASTRO");
            txtsenha.requestFocusInWindow();
            return;
        }
        
        if(ConfSenha.equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR A SENHA NOVAMENTE PARA REALIZAR SEU CADASTRO");
            txtcsenha.requestFocusInWindow();
            return;
        }
        
        if(!SSenha.equals(ConfSenha)){
            JOptionPane.showMessageDialog(rootPane, "FAVOR CONFIRMAR A SENHA PARA REALIZAR SEU CADASTRO");
            txtsenha.requestFocusInWindow();
            return;
        }
        
        if(txtemail.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O E-MAIL PARA REALIZAR SEU CADASTRO");
            txtemail.requestFocusInWindow();
            return;
        }
        
        if(txtcpf.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O CPF PARA REALIZAR SEU CADASTRO");
            txtcpf.requestFocusInWindow();
            return;
        }
        
        if(txtrua.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O NOME DA RUA PARA REALIZAR SEU CADASTRO");
            txtrua.requestFocusInWindow();
            return;
        }
        
        if(txtcompl.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O COMPLEMENTO DE ENDEREÇO PARA REALIZAR SEU CADASTRO");
            txtcompl.requestFocusInWindow();
            return;
        }
        
        if(txtbairro.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O BAIRRO PARA REALIZAR SEU CADASTRO");
            txtbairro.requestFocusInWindow();
            return;
        }
        
        if(txtcep.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O CEP PARA REALIZAR SEU CADASTRO");
            txtcep.requestFocusInWindow();
            return;
        }
        
        if(txtcidade.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "FAVOR INSERIR O NOME DA CIDADE PARA REALIZAR SEU CADASTRO");
            txtcidade.requestFocusInWindow();
            return;
        }
        
        int poslinha = du.LinhaUsuario(txtcodigousuario.getText());
        if(cmdNovo){
            if(poslinha != -1){ //usuário já existe
                txtcodigousuario.requestFocusInWindow();
                return;
            }
        }else{
            if(poslinha == 1){ //usuário não cadastrado ainda
                txtcodigousuario.requestFocusInWindow(); 
                return;
            }
        }
        
        Usuarios MUsuario = new Usuarios(txtcodigousuario.getText(), 
                                         txtnome.getText(), txtsnome.getText(),
                                         SSenha, ConfSenha, 
                                        (String)cmbperfil.getSelectedItem(), 
                                         txtemail.getText(),
                                         txtcpf.getText(),txtrua.getText(),
                                         txtcompl.getText(),txtbairro.getText(),
                                         txtcep.getText(), txtcidade.getText());

        String msg;
        if(cmdNovo){
            msg = du.CadUsuario(MUsuario);        
        }else{
            msg = du.EditarUsuario(MUsuario, poslinha);
        }
        JOptionPane.showMessageDialog(rootPane,msg);
        
        //Código do botão salvar cadastro
        //após ter um cadastro, já é possível que todos os botões estejam ativados
        cmdanterior.setEnabled(true);
        cmdproximo.setEnabled(true);
        cmdnovo.setEnabled(true);
        cmdalterar.setEnabled(true);
        cmdcancelar.setEnabled(false);
        cmdsalvar.setEnabled(false); 
        cmdpesquisar.setEnabled(true);
        
        txtcodigousuario.setEnabled(false);
        txtnome.setEnabled(false);
        txtsnome.setEnabled(false);
        txtsenha.setEnabled(false);
        txtcsenha.setEnabled(false);
        cmbperfil.setEnabled(false);
        txtemail.setEnabled(false);
        txtcpf.setEnabled(false);
        txtrua.setEnabled(false);
        txtcompl.setEnabled(false);
        txtbairro.setEnabled(false);
        txtcep.setEnabled(false);
        txtcidade.setEnabled(false);

        CarregarTable();
        return;    
    }//GEN-LAST:event_cmdsalvarActionPerformed

    private void cmdcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdcancelarActionPerformed
        //Código do botão cancelar cadastro
        cmdanterior.setEnabled(true);
        cmdproximo.setEnabled(true);
        cmdnovo.setEnabled(true);
        cmdalterar.setEnabled(true);
        cmdcancelar.setEnabled(false);
        cmdsalvar.setEnabled(false); 
        cmdpesquisar.setEnabled(true);
        
        txtcodigousuario.setEnabled(false);
        txtnome.setEnabled(false);
        txtsnome.setEnabled(false);
        txtsenha.setEnabled(false);
        txtcsenha.setEnabled(false);
        cmbperfil.setEnabled(false);
        txtemail.setEnabled(false);
        txtcpf.setEnabled(false);
        txtrua.setEnabled(false);
        txtcompl.setEnabled(false);
        txtbairro.setEnabled(false);
        txtcep.setEnabled(false);
        txtcidade.setEnabled(false);
    }//GEN-LAST:event_cmdcancelarActionPerformed

    private void cmdalterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdalterarActionPerformed
        // TODO add your handling code here:
        cmdanterior.setEnabled(false);
        cmdproximo.setEnabled(false);
        cmdnovo.setEnabled(false);
        cmdalterar.setEnabled(false);
        cmdcancelar.setEnabled(true); //caso queira cancelar, tem que ficar ativo
        cmdsalvar.setEnabled(true); //deixa ativo para salvar o cadastro
        cmdpesquisar.setEnabled(false);   
        
        //o código do usuário é único.
        txtnome.setEnabled(true);
        txtsnome.setEnabled(true);
        txtsenha.setEnabled(true);
        txtcsenha.setEnabled(true);
        cmbperfil.setEnabled(true);
        txtemail.setEnabled(true);
        txtcpf.setEnabled(true);
        txtrua.setEnabled(true);
        txtcompl.setEnabled(true);
        txtbairro.setEnabled(true);
        txtcep.setEnabled(true);
        txtcidade.setEnabled(true);
        
        cmdNovo = false;
        txtnome.requestFocusInWindow();
    }//GEN-LAST:event_cmdalterarActionPerformed

    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened
        visualizarCadastro();
        CarregarTable();
    }//GEN-LAST:event_formInternalFrameOpened

    private void cmdproximoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdproximoActionPerformed
        //Botão do próximo cadastro
        usuarioatual++;
        if(usuarioatual == du.NUsuarios()){
            usuarioatual = 0;
        }
        visualizarCadastro();
    }//GEN-LAST:event_cmdproximoActionPerformed

    private void cmdanteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdanteriorActionPerformed
        //Botão do cadastro anterior
        usuarioatual--;
        if(usuarioatual == -1){
            usuarioatual = du.NUsuarios()-1;
        }     
        visualizarCadastro();
    }//GEN-LAST:event_cmdanteriorActionPerformed

    private void cmddeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmddeletarActionPerformed
        // Código do botão deletar
        int Del = JOptionPane.showConfirmDialog(rootPane, "DESEJA DELETAR ESSE CADASTRO?");
        if(Del != 0){
            return;
        }
        String msg;
        msg = du.DeletarUsuario(usuarioatual);
        JOptionPane.showMessageDialog(rootPane,msg);
        
        usuarioatual = 0;//excluindo o escolhido ele volta ao primeiro cadastro
        visualizarCadastro();
        CarregarTable();
    }//GEN-LAST:event_cmddeletarActionPerformed
    
    private void visualizarCadastro(){
        txtcodigousuario.setText(du.getUsuarios()[usuarioatual].getIdusuario());
        txtnome.setText(du.getUsuarios()[usuarioatual].getNome());
        txtsnome.setText(du.getUsuarios()[usuarioatual].getSobrenome());
        txtsenha.setText(du.getUsuarios()[usuarioatual].getSenha());
        txtcsenha.setText(du.getUsuarios()[usuarioatual].getConfsenha());
        cmbperfil.setSelectedItem(du.getUsuarios()[usuarioatual].getPerfil());
        txtcpf.setText(du.getUsuarios()[usuarioatual].getCpf());
        txtemail.setText(du.getUsuarios()[usuarioatual].getEmail());
        txtrua.setText(du.getUsuarios()[usuarioatual].getRua());
        txtcompl.setText(du.getUsuarios()[usuarioatual].getComplem());
        txtbairro.setText(du.getUsuarios()[usuarioatual].getBairro());
        txtcep.setText(du.getUsuarios()[usuarioatual].getCep());
        txtcidade.setText(du.getUsuarios()[usuarioatual].getCidade());
    }

    private void CarregarTable(){
        String titulocabecalho[] = {"Cod Usuario", "Nome", "Sobrenome", "Perfil"}; //cabeçalho da tabela
        String RegCadastro[] = new String[4];
        Usertable = new DefaultTableModel(null, titulocabecalho);
        for(int i = 0; i < du.NUsuarios(); i++){
            RegCadastro[0] = du.getUsuarios()[i].getIdusuario();
            RegCadastro[1] = du.getUsuarios()[i].getNome();
            RegCadastro[2] = du.getUsuarios()[i].getSobrenome();
            RegCadastro[3] = "" + du.getUsuarios()[i].getPerfil();
            
            Usertable.addRow(RegCadastro);
        }
        Mtable.setModel(Usertable);
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Mtable;
    private javax.swing.JComboBox<String> cmbperfil;
    private javax.swing.JButton cmdalterar;
    private javax.swing.JButton cmdanterior;
    private javax.swing.JButton cmdcancelar;
    private javax.swing.JButton cmddeletar;
    private javax.swing.JButton cmdnovo;
    private javax.swing.JButton cmdpesquisar;
    private javax.swing.JButton cmdproximo;
    private javax.swing.JButton cmdsalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtbairro;
    private javax.swing.JTextField txtcep;
    private javax.swing.JTextField txtcidade;
    private javax.swing.JTextField txtcodigousuario;
    private javax.swing.JTextField txtcompl;
    private javax.swing.JTextField txtcpf;
    private javax.swing.JPasswordField txtcsenha;
    private javax.swing.JTextField txtemail;
    private javax.swing.JTextField txtnome;
    private javax.swing.JTextField txtrua;
    private javax.swing.JPasswordField txtsenha;
    private javax.swing.JTextField txtsnome;
    // End of variables declaration//GEN-END:variables
}
