package Construtivos;
public class Clientes {
    //Atributos
    private String codigoCliente;
    private String cpfCliente;
    private String nomeCliente;
    private String emailCliente;
    private String senhaCliente;
    private String enderecoCliente;
    private String endereco2Cliente;
    private String endereco3Cliente;
    private String cidadeCliente;
    private String dataVenda;
    
    //Construtor
    public Clientes(String codigoCliente, String cpfCliente, String nomeCliente, 
                    String emailCliente, String senhaCliente, 
                    String enderecoCliente, String endereco2Cliente, 
                    String endereco3Cliente, String cidadeCliente, 
                    String dataVenda) {
        this.codigoCliente = codigoCliente;
        this.cpfCliente = cpfCliente;
        this.nomeCliente = nomeCliente;
        this.emailCliente = emailCliente;
        this.senhaCliente = senhaCliente;
        this.enderecoCliente = enderecoCliente;
        this.endereco2Cliente = endereco2Cliente;
        this.endereco3Cliente = endereco3Cliente;
        this.cidadeCliente = cidadeCliente;
        this.dataVenda = dataVenda;
    }
    
    //Getters e Setters
    public String getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public String getCpfCliente() {
        return cpfCliente;
    }

    public void setCpfCliente(String cpfCliente) {
        this.cpfCliente = cpfCliente;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public String getEmailCliente() {
        return emailCliente;
    }

    public void setEmailCliente(String emailCliente) {
        this.emailCliente = emailCliente;
    }

    public String getSenhaCliente() {
        return senhaCliente;
    }

    public void setSenhaCliente(String senhaCliente) {
        this.senhaCliente = senhaCliente;
    }

    public String getEnderecoCliente() {
        return enderecoCliente;
    }

    public void setEnderecoCliente(String enderecoCliente) {
        this.enderecoCliente = enderecoCliente;
    }

    public String getEndereco2Cliente() {
        return endereco2Cliente;
    }

    public void setEndereco2Cliente(String endereco2Cliente) {
        this.endereco2Cliente = endereco2Cliente;
    }

    public String getEndereco3Cliente() {
        return endereco3Cliente;
    }

    public void setEndereco3Cliente(String endereco3Cliente) {
        this.endereco3Cliente = endereco3Cliente;
    }

    public String getCidadeCliente() {
        return cidadeCliente;
    }

    public void setCidadeCliente(String cidadeCliente) {
        this.cidadeCliente = cidadeCliente;
    }

    public String getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(String dataVenda) {
        this.dataVenda = dataVenda;
    }    
}