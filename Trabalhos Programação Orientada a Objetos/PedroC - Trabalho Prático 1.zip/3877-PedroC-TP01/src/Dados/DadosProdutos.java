package Dados;

import Construtivos.Produtos;

public class DadosProdutos {
    //Dados para os produtos
    private int maxprodutos = 100;
    private Produtos Mprodutos[] = new Produtos[maxprodutos];
    private int contprodutos = 0;
    
    public DadosProdutos(){
        //CRIANDO O CADASTRO DE PRODUTOS
        Produtos Mproduto;
        //criando o primeiro produto
        Mproduto = new Produtos("1", "CD", "CDs de músicas de estilos variados",
                                "R$10,00", "15", "Musical");
        Mprodutos[contprodutos] = Mproduto;
        contprodutos ++;
    }
    
    //Mostrar o número de cadastros de produtos
    public int NProdutos(){ //OK
        return contprodutos;
    }
    
    public Produtos[] getProdutos(){
        return Mprodutos;
    }
    
    //Verificando se o produto já existe
    public int LinhaProduto(String produto){
        for(int i = 0; i < contprodutos; i++){
            //agora será verificado se é possível fazer cadastro
            if(Mprodutos[i].getCodproduto().equals(produto)){
                return i;
            }
        }
        return -1;
    }
    
    //Método para cadastrar produtos
    public String CadProduto(Produtos MMprodutos){
        if(contprodutos == maxprodutos){
            return "VOCÊ NÃO POSSUI MAIS ESPAÇO PARA CADASTROS DE PRODUTOS";
        }else{
            Mprodutos[contprodutos] = MMprodutos;
            contprodutos++;
            return "PRODUTO CADASTRADO COM SUCESSO";
        }
    }
    
    //Método para editar no cadastro do produto
    public String EditarProduto(Produtos MMprodutos, int poslinha){
        //Código é único
        Mprodutos[poslinha].setNome(MMprodutos.getNome());
        Mprodutos[poslinha].setDesc(MMprodutos.getDesc());
        Mprodutos[poslinha].setPreco(MMprodutos.getPreco());
        Mprodutos[poslinha].setQtd(MMprodutos.getQtd());
        Mprodutos[poslinha].setCategoria(MMprodutos.getCategoria());
        return "PRODUTO EDITADO COM SUCESSO";
    }
    
    //Método para deletar um produto
    public String DeletarProduto(int poslinha){ 
        for(int i = poslinha; i < contprodutos - 1; i ++){
            Mprodutos[i] = Mprodutos[i + 1];
        }
        contprodutos --;
        return "PRODUTO DELETADO COM SUCESSO";
    }     
}
