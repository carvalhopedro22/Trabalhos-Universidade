package Dados;

import Construtivos.Vendas;

public class DadosVendas {
    //Dados para as vendas
    private int maxvendas = 20;
    private Vendas Mvendas[] = new Vendas[maxvendas];
    private int contvendas = 0;
    
    public DadosVendas(){
        //CRIANDO O CADASTRO DE VENDAS
        Vendas Mvenda;
        //criando a primeira venda
        Mvenda = new Vendas("1","Jogos","Bruno","Primeiro","200","25/04/2021",
                            "28/04/2021","2","Entregue","R$400");
        Mvendas[contvendas] = Mvenda;
        contvendas++;
    }
    
    //Mostrar o número de vendas
    public int NVendas(){
        return contvendas;
    }
    
    public Vendas[] getVendas(){
        return Mvendas;
    }
    
    //Verificando se a venda já existe
    public int LinhaVenda(String venda){
        for(int i = 0; i < contvendas; i++){
            if(Mvendas[i].getCodigovenda().equals(venda)){
                return i;
            }
        }
        return -1;
    }
    
    //Método para cadastrar vendas
    public String CadVendas(Vendas MMvendas){
        if(contvendas == maxvendas){
            return "VOCÊ NÃO POSSUI MAIS ESPAÇO PARA CADASTROS DE VENDAS";
        }else{
            Mvendas[contvendas] = MMvendas;
            contvendas++;
            return "VENDA CADASTRADA COM SUCESSO";
        }
    }
    
     //Método para editar no cadastro de vendas
    public String EditarVenda(Vendas MMvendas, int poslinha){
        //código não precisa, pois é único
        Mvendas[poslinha].setProdutoComprado(MMvendas.getProdutoComprado());
        Mvendas[poslinha].setNomeCliente(MMvendas.getNomeCliente());
        Mvendas[poslinha].setEnderecoEntrega(MMvendas.getEnderecoEntrega());
        Mvendas[poslinha].setPreco(MMvendas.getPreco());
        Mvendas[poslinha].setDataInicial(MMvendas.getDataInicial());
        Mvendas[poslinha].setDataFinal(MMvendas.getDataFinal());
        Mvendas[poslinha].setQtd(MMvendas.getQtd());
        Mvendas[poslinha].setStatus(MMvendas.getStatus());
        Mvendas[poslinha].setTotalPagar(MMvendas.getTotalPagar());
        return "VENDA EDITADA COM SUCESSO";
    }
    
    //Método para deletar uma venda
    public String DeletarVenda(int poslinha){
        for(int i = poslinha; i < contvendas -1; i++){
            Mvendas[i] = Mvendas[i+1];
        }
        contvendas --;
        return "VENDA DELETADA COM SUCESSO";
    }
}
