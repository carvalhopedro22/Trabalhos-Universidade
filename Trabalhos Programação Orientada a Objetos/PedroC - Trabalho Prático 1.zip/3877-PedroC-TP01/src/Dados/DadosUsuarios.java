package Dados;

import Construtivos.Usuarios;

public class DadosUsuarios {
    //Dados para os usuários
    private int maxusuarios = 50;
    private Usuarios Musuarios[] = new Usuarios[maxusuarios];
    private int contusuario = 0;
    
    public DadosUsuarios(){
        //CRIANDO O CADASTRO DE USUÁRIOS
        Usuarios Musuario;
        //criando o primeiro usuário como administrador
        Musuario = new Usuarios("3877","Thomas","Ribeiro","1221","1221",
                                "Administrador","thomas.rib@mail.br",
                                "123456789","Fonseca","214 ap02","centro",
                                "38750000","Presidente O.");
        Musuarios[contusuario] = Musuario;
        contusuario++;
    }
    
    //Mostrar o número de cadastros de usuários
    public int NUsuarios(){ 
        return contusuario;
    }
    
    public Usuarios[] getUsuarios(){ 
        return Musuarios;
    }
    
    //Método para validar os campos na interface:
    public boolean validarUsuario(String usuario, String senha){
        boolean x = false;
        for(int i = 0; i < contusuario; i++){
            //agora será verificado se é possível fazer login
            if(Musuarios[i].getNome().equals(usuario) && 
               Musuarios[i].getSenha().equals(senha)){
                return true;
            }
        }
        return false;
    }
    
    //Verificando se o usuário já existe
    public int LinhaUsuario(String usuario){ 
        for(int i = 0; i < contusuario; i++){
            //agora será verificado se é possível fazer login
            if(Musuarios[i].getIdusuario().equals(usuario)){
                return i;
            }
        }
        return -1;
    }
    
    //Método para cadastrar usuários
    public String CadUsuario(Usuarios MMusuario){ 
        if(contusuario == maxusuarios){
            return "VOCÊ NÃO POSSUI MAIS ESPAÇO PARA CADASTROS DE USUÁRIOS";
        }else{
            Musuarios[contusuario] = MMusuario;
            contusuario++;
            return "USUÁRIO CADASTRADO COM SUCESSO";
        }
    }
    
    //Método para editar no cadastro do usuário
    public String EditarUsuario(Usuarios MMusuario, int poslinha){ 
        //código não precisa, pois é único
        Musuarios[poslinha].setNome(MMusuario.getNome());
        Musuarios[poslinha].setSobrenome(MMusuario.getSobrenome());
        Musuarios[poslinha].setSenha(MMusuario.getSenha());
        Musuarios[poslinha].setConfsenha(MMusuario.getConfsenha());
        Musuarios[poslinha].setPerfil(MMusuario.getPerfil());
        Musuarios[poslinha].setEmail(MMusuario.getEmail());
        Musuarios[poslinha].setCpf(MMusuario.getCpf());
        Musuarios[poslinha].setRua(MMusuario.getRua());
        Musuarios[poslinha].setComplem(MMusuario.getComplem());
        Musuarios[poslinha].setBairro(MMusuario.getBairro());
        Musuarios[poslinha].setCep(MMusuario.getCep());
        Musuarios[poslinha].setCidade(MMusuario.getCidade());
        return "USUÁRIO EDITADO COM SUCESSO";
    }
    
    //Método para deletar um usuário
    public String DeletarUsuario(int poslinha){ 
        for(int i = poslinha; i < contusuario - 1; i ++){
            Musuarios[i] = Musuarios[i + 1]; 
        }
        contusuario --;
        return "USUÁRIO DELETADO COM SUCESSO";
    }
}
