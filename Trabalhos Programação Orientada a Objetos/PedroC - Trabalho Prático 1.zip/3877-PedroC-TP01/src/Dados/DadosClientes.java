package Dados;

import Construtivos.Clientes;

public class DadosClientes {
    //Dados para os clientes
    private int maxclientes = 150;
    private Clientes Mclientes[] = new Clientes[maxclientes];
    private int contclientes = 0;
    
    public DadosClientes(){
        //CRIANDO O CADASTRO DE CLIENTES
        Clientes Mcliente;
        //criando o primeiro cliente
        Mcliente = new Clientes("10","02135421432","Bruno","bruno@gmail.com",
                "3353", "Rua Alirio Martins, 250-ap03", "Rua JK, 345-casa3", 
                "Rua Major Gote, 456-ap7", "Cidade da Luz", 
                "2021/03/21");
        Mclientes[contclientes] = Mcliente;
        contclientes ++;
    }
    
    //Mostrar o número de cadastros de clientes
    public int NClientes(){
        return contclientes;
    }
    
    public Clientes[] getClientes(){
        return Mclientes;
    }
    
    //Verificando se o cliente já existe
    public int LinhaCliente(String cliente){
        for(int i = 0; i < contclientes; i++){
            //agora será verificado se é possível fazer cadastro
            if(Mclientes[i].getCodigoCliente().equals(cliente)){
                return i;
            }
        }
        return -1;
    }
    
    //Método para cadastrar clientes
    public String CadCliente(Clientes MMclientes){
        if(contclientes == maxclientes){
            return "VOCÊ NÃO POSSUI MAIS ESPAÇO PARA CADASTROS DE CLIENTES";
        }else{
            Mclientes[contclientes] = MMclientes;
            contclientes++;
            return "CLIENTE CADASTRADO COM SUCESSO";
        }
    }
    
    //Método para editar no cadastro do cliente
    public String EditarCliente(Clientes MMclientes, int poslinha){
        //código não precisa, pois é único
        Mclientes[poslinha].setCpfCliente(MMclientes.getCpfCliente());
        Mclientes[poslinha].setNomeCliente(MMclientes.getNomeCliente());
        Mclientes[poslinha].setEmailCliente(MMclientes.getEmailCliente());
        Mclientes[poslinha].setSenhaCliente(MMclientes.getSenhaCliente());
        Mclientes[poslinha].setEnderecoCliente(MMclientes.getEnderecoCliente());
        Mclientes[poslinha].setCidadeCliente(MMclientes.getCidadeCliente());
        Mclientes[poslinha].setDataVenda(MMclientes.getDataVenda());
        return "CLIENTE EDITADO COM SUCESSO";
    }
    
    //Método para deletar um cliente
    public String DeletarCliente(int poslinha){
        for(int i = poslinha; i < contclientes -1; i ++){
            Mclientes[i] = Mclientes[i + 1];
        }
        contclientes --;
        return "CLIENTE DELETADO COM SUCESSO";
    }
}
