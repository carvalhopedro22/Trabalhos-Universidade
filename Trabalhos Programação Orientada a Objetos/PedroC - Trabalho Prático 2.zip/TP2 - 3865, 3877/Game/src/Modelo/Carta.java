package Modelo;

public class Carta {
    //Atributos
    private int id;
    private String url;
    private boolean isVirada;   
    
    //Construtor
    public Carta(int id, String url){
        this.isVirada = false;
        this.id = id;
        this.url = url;
    }
    
    //Métodos
    public void VirarCarta(){
        this.isVirada = false;
    }   
    
    public boolean isVirada(){
        return this.isVirada;
    }
    
    public void setVirada(){
        this.isVirada = true;
    }
    
    public int GetId(){
        return id;
    }

    public String getUrl() {
        return url;
    }

    void setVirada(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }  
}