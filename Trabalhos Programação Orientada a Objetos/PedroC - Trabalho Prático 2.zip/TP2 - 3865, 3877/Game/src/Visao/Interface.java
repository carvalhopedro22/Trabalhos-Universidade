package Visao;

import java.awt.Color;
import java.awt.Image;
import java.awt.Insets;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import Modelo.Tabuleiro;

public class Interface extends javax.swing.JFrame {
    
    private Tabuleiro t = new Tabuleiro(8);
    private int cartasViradas = 0;
    int[] paresEncontrados = new int[4];
    private int start = -1;
    private int contaPontoJogador = 0;
    private int contaPontoBot = 0;
    
    int[] Bot = new int[8];
    
    public void inicializavetor(){
        for(int i=0; i<4; i++){
            paresEncontrados[i] = -1; 
        }
    }
    
    public void contabilizaPontos(){
        for (int i = 0; i < 4; i++){
            if(paresEncontrados[i] != -1){
               pontojog.setText(String.valueOf(contaPontoJogador));
            }
        }
    }
   
    public Interface() {
        initComponents();
        System.out.println(btn1);   
    }
    
    public void ImprimeVetor(){
        for(int i=0; i<4; i++){
            if(paresEncontrados[i] != -1){
                System.out.println("Id encontrado: "+paresEncontrados[i]);
            }
        }
    }
    
    public void escondeCarta() throws IOException{
        Image img;
        img = ImageIO.read(getClass().getResource("../Imagens/sinal-de-interrogacao.png"));
        if(t.getCartas().get(0).isVirada() && paresEncontrados[t.getCartas().get(0).GetId()] == -1){
            this.btn1.setIcon(new ImageIcon(img));
            t.getCartas().get(0).VirarCarta();
        }
        if(t.getCartas().get(1).isVirada() && paresEncontrados[t.getCartas().get(1).GetId()] == -1){
            btn2.setIcon(new ImageIcon(img));
            t.getCartas().get(1).VirarCarta();
        }
        if(t.getCartas().get(2).isVirada() && paresEncontrados[t.getCartas().get(2).GetId()] == -1){
            btn3.setIcon(new ImageIcon(img));
            t.getCartas().get(2).VirarCarta();
        }
        if(t.getCartas().get(3).isVirada() && paresEncontrados[t.getCartas().get(3).GetId()] == -1){
            btn4.setIcon(new ImageIcon(img));
            t.getCartas().get(3).VirarCarta();
        }
        if(t.getCartas().get(4).isVirada() && paresEncontrados[t.getCartas().get(4).GetId()] == -1){
            btn5.setIcon(new ImageIcon(img));
            t.getCartas().get(4).VirarCarta();
        }
        if(t.getCartas().get(5).isVirada() && paresEncontrados[t.getCartas().get(5).GetId()] == -1){
            btn6.setIcon(new ImageIcon(img));
            t.getCartas().get(5).VirarCarta();
        }
        if(t.getCartas().get(6).isVirada() && paresEncontrados[t.getCartas().get(6).GetId()] == -1){
            btn7.setIcon(new ImageIcon(img));
            t.getCartas().get(6).VirarCarta();
        }
        if(t.getCartas().get(7).isVirada() && paresEncontrados[t.getCartas().get(7).GetId()] == -1){
            btn8.setIcon(new ImageIcon(img));
            t.getCartas().get(7).VirarCarta();
        }
    }

    public static int aleatoriar(int minimo, int maximo) {
        Random random = new Random();
        return random.nextInt((maximo - minimo) + 1) + minimo;
    }
    
    public void JogadasBot() throws IOException{ 
        int num = 0;
        int num2 = 0;
        do{
            num = aleatoriar(0, 7);    
            num2 = aleatoriar(0, 7);
        }while(num == num2 && t.getCartas().get(num).isVirada() == false && t.getCartas().get(num2).isVirada() == false);
        Image img;
        if(t.getCartas().get(num).GetId() == t.getCartas().get(num2).GetId()){
            contaPontoBot++;
            paresEncontrados[t.getCartas().get(num).GetId()] = t.getCartas().get(num2).GetId();
            if(t.getCartas().get(0).GetId() == t.getCartas().get(num).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num).getUrl()));
                btn1.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(1).GetId() == t.getCartas().get(num).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num).getUrl()));
                btn2.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(2).GetId() == t.getCartas().get(num).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num).getUrl()));
                btn3.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(3).GetId() == t.getCartas().get(num).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num).getUrl()));
                btn4.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(4).GetId() == t.getCartas().get(num).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num).getUrl()));
                btn5.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(5).GetId() == t.getCartas().get(num).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num).getUrl()));
                btn6.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(6).GetId() == t.getCartas().get(num).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num).getUrl()));
                btn7.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(7).GetId() == t.getCartas().get(num).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num).getUrl()));
                btn8.setIcon(new ImageIcon(img));
            }

            if(t.getCartas().get(0).GetId() == t.getCartas().get(num2).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num2).getUrl()));
                btn1.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(1).GetId() == t.getCartas().get(num2).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num2).getUrl()));
                btn2.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(2).GetId() == t.getCartas().get(num2).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num2).getUrl()));
                btn3.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(3).GetId() == t.getCartas().get(num2).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num2).getUrl()));
                btn4.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(4).GetId() == t.getCartas().get(num2).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num2).getUrl()));
                btn5.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(5).GetId() == t.getCartas().get(num2).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num2).getUrl()));
                btn6.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(6).GetId() == t.getCartas().get(num2).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num2).getUrl()));
                btn7.setIcon(new ImageIcon(img));
            }
            if(t.getCartas().get(7).GetId() == t.getCartas().get(num2).GetId()){
                img = ImageIO.read(getClass().getResource(t.getCartas().get(num2).getUrl()));
                btn8.setIcon(new ImageIcon(img));
            }
        }   
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btn1 = new javax.swing.JButton();
        btn5 = new javax.swing.JButton();
        btn2 = new javax.swing.JButton();
        btn6 = new javax.swing.JButton();
        btn3 = new javax.swing.JButton();
        btn7 = new javax.swing.JButton();
        btn4 = new javax.swing.JButton();
        btn8 = new javax.swing.JButton();
        btniniciar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        pontojog = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Jogo da Memória");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 0)));

        btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn1ActionPerformed(evt);
            }
        });

        btn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn5ActionPerformed(evt);
            }
        });

        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });

        btn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn6ActionPerformed(evt);
            }
        });

        btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn3ActionPerformed(evt);
            }
        });

        btn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn7ActionPerformed(evt);
            }
        });

        btn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn4ActionPerformed(evt);
            }
        });

        btn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn8ActionPerformed(evt);
            }
        });

        btniniciar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btniniciar.setForeground(new java.awt.Color(0, 0, 204));
        btniniciar.setText("Iniciar/Reiniciar");
        btniniciar.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(0, 0, 204)));
        btniniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btniniciarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setText("Placar:");

        pontojog.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        pontojog.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pontojog.setText("0");
        pontojog.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 204)));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("0");
        jLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 255)));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setText("Você:");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 204));
        jLabel5.setText("Computador:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn1, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                            .addComponent(btn5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn4, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addComponent(btniniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(122, 122, 122)
                                .addComponent(jLabel2)))
                        .addGap(59, 59, 59))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pontojog, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(89, 89, 89))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(132, 132, 132)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(pontojog, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn8, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addComponent(btn5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(63, 63, 63)
                        .addComponent(btniniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
        if(start == -1){
            return;
        }
        System.out.println(t.getCartas().get(0).isVirada());
        if(t.getCartas().get(0).isVirada()){
            return;
        }else{
            try {
                System.out.println(t.getCartas().get(0).GetId());
                Image img;
                img = ImageIO.read(getClass().getResource(t.getCartas().get(0).getUrl()));
                btn1.setIcon(new ImageIcon(img));
                t.getCartas().get(0).setVirada();
                cartasViradas++;
                if(cartasViradas == 2){
                    for(int i =0;i<8;i++){
                        if(i == 0){
                            continue;
                        }
                        if(t.getCartas().get(0).GetId() == t.getCartas().get(i).GetId() && (t.getCartas().get(i).isVirada())){
                            paresEncontrados[t.getCartas().get(0).GetId()] = t.getCartas().get(0).GetId();
                            cartasViradas = 0;
                            contaPontoJogador++;
                            contabilizaPontos();
                        }
                    }
                    cartasViradas = 0;
                    escondeCarta();
               }     
                ImprimeVetor();
            } catch (Exception ex) {
                Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
        
        
    }//GEN-LAST:event_btn1ActionPerformed

    private void btniniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btniniciarActionPerformed

        start = 1;
        ArrayList<javax.swing.JButton> list = new ArrayList<javax.swing.JButton>();
        list.add(btn1);
        list.add(btn2);
        list.add(btn3);
        list.add(btn4);
        list.add(btn5);
        list.add(btn6);
        list.add(btn7);
        list.add(btn8);
        
        list.forEach((btn)->btn.setIcon(null));

        Image img;
        try {
            t.EmbaralharCartas();
            System.out.println("Amem");
            img = ImageIO.read(getClass().getResource("../Imagens/sinal-de-interrogacao.png"));
            cartasViradas = 0;
            contaPontoJogador = 0;
            contaPontoBot = 0;
            pontojog.setText(String.valueOf(contaPontoJogador));
            btn1.setIcon(new ImageIcon(img));
            btn2.setIcon(new ImageIcon(img));
            btn3.setIcon(new ImageIcon(img)); 
            btn4.setIcon(new ImageIcon(img));
            btn5.setIcon(new ImageIcon(img));
            btn6.setIcon(new ImageIcon(img));
            btn7.setIcon(new ImageIcon(img));
            btn8.setIcon(new ImageIcon(img));
            inicializavetor();
        } catch (Exception ex) {
            Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);     
        }
    }//GEN-LAST:event_btniniciarActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
        if(start == -1){
            return;
        }
        System.out.println(t.getCartas().get(1).isVirada());
        if(t.getCartas().get(1).isVirada()){
            return;
        }else{
            try {
                System.out.println(t.getCartas().get(1).GetId());
                Image img;
                img = ImageIO.read(getClass().getResource(t.getCartas().get(1).getUrl()));
                btn2.setIcon(new ImageIcon(img));
                t.getCartas().get(1).setVirada();
                cartasViradas++;
                
                if(cartasViradas == 2){
                    for(int i =0;i<8;i++){
                        if(i == 1){
                            continue;
                        }
                        if(t.getCartas().get(1).GetId() == t.getCartas().get(i).GetId() && (t.getCartas().get(i).isVirada())){
                            paresEncontrados[t.getCartas().get(1).GetId()] = t.getCartas().get(1).GetId();
                            cartasViradas = 0;
                            contaPontoJogador++;
                            contabilizaPontos();
                        }
                    }
                    cartasViradas = 0;
                    escondeCarta();
                }
                 ImprimeVetor();
                
            } catch (IOException ex) {
                Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
                }
        }  
    }//GEN-LAST:event_btn2ActionPerformed

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
        if(start == -1){
            return;
        }
        System.out.println(t.getCartas().get(0).isVirada());
        if(t.getCartas().get(2).isVirada()){
            return;
        }else{
            try {
                System.out.println(t.getCartas().get(2).GetId());
                Image img;
                img = ImageIO.read(getClass().getResource(t.getCartas().get(2).getUrl()));
                btn3.setIcon(new ImageIcon(img));
                t.getCartas().get(2).setVirada();
                cartasViradas++;
                
                if(cartasViradas == 2){
                    for(int i =0;i<8;i++){
                        if(i == 2){
                            continue;
                        }
                        if(t.getCartas().get(2).GetId() == t.getCartas().get(i).GetId() && (t.getCartas().get(i).isVirada())){
                            paresEncontrados[t.getCartas().get(2).GetId()] = t.getCartas().get(2).GetId();
                            cartasViradas = 0;
                            contaPontoJogador++;
                            contabilizaPontos();
                        }
                    }
                    cartasViradas = 0;
                    escondeCarta();
               }     
                ImprimeVetor();
            } catch (Exception ex) {
                Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
         
    }//GEN-LAST:event_btn3ActionPerformed

    private void btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn4ActionPerformed
        if(start == -1){
            return;
        }
        System.out.println(t.getCartas().get(3).isVirada());
        if(t.getCartas().get(3).isVirada()){
        return;
        }else{
            try {
                System.out.println(t.getCartas().get(3).GetId());
                Image img;
                img = ImageIO.read(getClass().getResource(t.getCartas().get(3).getUrl()));
                btn4.setIcon(new ImageIcon(img));
                t.getCartas().get(3).setVirada();
                cartasViradas++;
                
                if(cartasViradas == 2){
                    for(int i =0;i<8;i++){
                        if(i == 3){
                            continue;
                        }
                        if(t.getCartas().get(3).GetId() == t.getCartas().get(i).GetId() && (t.getCartas().get(i).isVirada())){
                            paresEncontrados[t.getCartas().get(3).GetId()] = t.getCartas().get(3).GetId();
                            cartasViradas = 0;
                            contaPontoJogador++;
                            contabilizaPontos();
                        }
                    }
                    cartasViradas = 0;
                    escondeCarta();
                }
                ImprimeVetor();
            } catch (Exception ex) {
                Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
                }
        }  
    }//GEN-LAST:event_btn4ActionPerformed

    private void btn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn5ActionPerformed
        if(start == -1){
            return;
        }
        System.out.println(t.getCartas().get(4).isVirada());
        if(t.getCartas().get(4).isVirada()){
        return;
        }else{
            try {
                System.out.println(t.getCartas().get(4).GetId());
                Image img;
                img = ImageIO.read(getClass().getResource(t.getCartas().get(4).getUrl()));
                btn5.setIcon(new ImageIcon(img));
                t.getCartas().get(4).setVirada();
                cartasViradas++;
                
                if(cartasViradas == 2){
                    for(int i =0;i<8;i++){
                        if(i == 4){
                            continue;
                        }
                        if(t.getCartas().get(4).GetId() == t.getCartas().get(i).GetId() && (t.getCartas().get(i).isVirada())){
                            paresEncontrados[t.getCartas().get(4).GetId()] = t.getCartas().get(4).GetId();
                            cartasViradas = 0;
                            contaPontoJogador++;
                            contabilizaPontos();
                        }
                    }
                    cartasViradas = 0;
                    escondeCarta();
                }
                ImprimeVetor();
            } catch (Exception ex) {
                Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
                }
        }  
    }//GEN-LAST:event_btn5ActionPerformed

    private void btn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn6ActionPerformed
        if(start == -1){
            return;
        }
        System.out.println(t.getCartas().get(5).isVirada());
        if(t.getCartas().get(5).isVirada()){
        return;
        }else{
            try {
                System.out.println(t.getCartas().get(5).GetId());
                Image img;
                img = ImageIO.read(getClass().getResource(t.getCartas().get(5).getUrl()));
                btn6.setIcon(new ImageIcon(img));
                t.getCartas().get(5).setVirada();
                cartasViradas++;
                
                if(cartasViradas == 2){
                    for(int i =0;i<8;i++){
                        if(i == 5){
                            continue;
                        }
                        if(t.getCartas().get(5).GetId() == t.getCartas().get(i).GetId() && (t.getCartas().get(i).isVirada())){
                            paresEncontrados[t.getCartas().get(5).GetId()] = t.getCartas().get(5).GetId();
                            cartasViradas = 0;
                            contaPontoJogador++;
                            contabilizaPontos();
                        }
                    }
                    cartasViradas = 0;
                    escondeCarta();
                }
                ImprimeVetor();
            } catch (Exception ex) {
                Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
                }
        }  
    }//GEN-LAST:event_btn6ActionPerformed

    private void btn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn7ActionPerformed
        if(start == -1){
            return;
        }
        System.out.println(t.getCartas().get(6).isVirada());
        if(t.getCartas().get(6).isVirada()){
            return;
        }else{
            try {
                System.out.println(t.getCartas().get(6).GetId());
                Image img;
                img = ImageIO.read(getClass().getResource(t.getCartas().get(6).getUrl()));
                btn7.setIcon(new ImageIcon(img));
                t.getCartas().get(6).setVirada();
                cartasViradas++;
                
                if(cartasViradas == 2){
                    for(int i =0;i<8;i++){
                        if(i == 6){
                            continue;
                        }
                        if(t.getCartas().get(6).GetId() == t.getCartas().get(i).GetId() && (t.getCartas().get(i).isVirada())){
                            paresEncontrados[t.getCartas().get(6).GetId()] = t.getCartas().get(6).GetId();
                            cartasViradas = 0;
                            contaPontoJogador++;
                            contabilizaPontos();
                        }
                    }
                    cartasViradas = 0;
                    escondeCarta();
                }
                ImprimeVetor();
            } catch (Exception ex) {
                Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
                }
        }          // TODO add your handling code here:
    }//GEN-LAST:event_btn7ActionPerformed

    private void btn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn8ActionPerformed
        if(start == -1){
            return;
        }
        System.out.println(t.getCartas().get(7).isVirada());
        if(t.getCartas().get(7).isVirada()){
        return;
        }else{
            try {
                System.out.println(t.getCartas().get(7).GetId());
                Image img;
                img = ImageIO.read(getClass().getResource(t.getCartas().get(7).getUrl()));
                btn8.setIcon(new ImageIcon(img));
                t.getCartas().get(7).setVirada();
                cartasViradas++;
                
                if(cartasViradas == 2){
                    for(int i =0;i<8;i++){
                        if(i == 7){
                            continue;
                        }
                        if(t.getCartas().get(7).GetId() == t.getCartas().get(i).GetId() && (t.getCartas().get(i).isVirada())){
                            paresEncontrados[t.getCartas().get(7).GetId()] = t.getCartas().get(7).GetId();
                            cartasViradas = 0;
                            contaPontoJogador++;
                            contabilizaPontos();
                        }
                    }
                    cartasViradas = 0;
                    escondeCarta();   
                }
                ImprimeVetor();
            } catch (Exception ex) {
                Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
                }
        }  
    }//GEN-LAST:event_btn8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interface().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn1;
    private javax.swing.JButton btn2;
    private javax.swing.JButton btn3;
    private javax.swing.JButton btn4;
    private javax.swing.JButton btn5;
    private javax.swing.JButton btn6;
    private javax.swing.JButton btn7;
    private javax.swing.JButton btn8;
    private javax.swing.JButton btniniciar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel pontojog;
    // End of variables declaration//GEN-END:variables
}


