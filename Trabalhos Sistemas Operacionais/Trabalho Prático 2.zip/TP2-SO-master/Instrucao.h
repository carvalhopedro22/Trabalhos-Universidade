#ifndef INSTRUCAO_H
#define INSTRUCAO_H

typedef struct {
    char i;
    int num;
    int n1;
    int n2;
    char arq[50];
} Instrucao;

#endif