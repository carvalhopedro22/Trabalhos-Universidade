# Trabalho Prático 2 - Sistemas Operacionais

## Trabalho
Simulação de Gerenciamento de Processos

## Objetivo
Simular cinco funções do gerenciamento de processos: criar processo, substituir a imagem atual do processo com uma imagem nova do processo, transição de estado do processo, escalonamento de processos e troca de contexto.