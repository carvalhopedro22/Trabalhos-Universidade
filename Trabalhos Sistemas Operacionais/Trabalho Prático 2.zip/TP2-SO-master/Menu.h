#ifndef MENU_H
#define MENU_H

#include "Pipe.h"

void menu(Pipe *p);

#endif