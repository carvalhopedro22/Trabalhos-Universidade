#ifndef INTERFACE_H
#define INTERFACE_H

#include "Particao.h"

void help();

void menu();

void execucaoManual(Particao particao);

void execucaoAutomatica(Particao particao);

#endif