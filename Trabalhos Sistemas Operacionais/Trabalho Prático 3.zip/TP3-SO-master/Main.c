#include <stdlib.h>

#include "Interface.h"
#include "GerenciadorDeArquivos.h"

int main() {
    //char *desc;
    menu();

    //lerArquivo("test.txt", &desc);

    //printf("%s\n\n", desc);

    //lerArquivo("test.txt", desc);

    //printf("\nSucesso!\n");
    

    return 0;

}