USE trabalhobdexpandido;
-- -----------------------------------------------------
-- Questão 13
-- Pergunta 1
-- -----------------------------------------------------
SELECT `nomealbum`, `banda/cantor`, MAX(`ano_lancamento`), `nomemid`
FROM albumMusica NATURAL JOIN midia
WHERE `banda/cantor` = 'Why Don`t We';

-- -----------------------------------------------------
-- Questão 13
-- Pergunta 2
-- -----------------------------------------------------
-- Ordem pelo nome do álbum
SELECT `nomealbum`, `banda/cantor`, `ano_lancamento`, `nomemid`
FROM albumMusica NATURAL JOIN midia
ORDER BY `nomealbum`;

-- Ordem pelo nome da banda ou cantor
SELECT `nomealbum`, `banda/cantor`, `ano_lancamento`, `nomemid`
FROM albumMusica NATURAL JOIN midia
ORDER BY `banda/cantor`;

-- Ordem pelo ano de lançamento do álbum
SELECT `nomealbum`, `banda/cantor`, `ano_lancamento`, `nomemid`
FROM albumMusica NATURAL JOIN midia
ORDER BY `ano_lancamento`;

-- -----------------------------------------------------
-- Questão 13
-- Pergunta 3
-- -----------------------------------------------------
INSERT INTO `trabalhobdexpandido`.`albumMusica`(`idalbumMusica`, `nomealbum`, `banda/cantor`, `ano_lancamento`, `idmidia`) 
VALUES(6, '8 Letters', 'Why Don`t We', 2016, 9);
INSERT INTO `trabalhobdexpandido`.`albumMusica`(`idalbumMusica`, `nomealbum`, `banda/cantor`, `ano_lancamento`, `idmidia`) 
VALUES(7, 'A Why Don`t We Christmas', 'Why Don`t We', 2017, 8);
SELECT `nomealbum`, `banda/cantor`, `ano_lancamento`, `nomemid`
FROM albumMusica NATURAL JOIN midia
WHERE `banda/cantor` = 'Why Don`t We'
ORDER BY `ano_lancamento` DESC;

-- -----------------------------------------------------
-- Questão 13
-- Pergunta 4
-- -----------------------------------------------------
SELECT `nomealbum`, `banda/cantor`, `ano_lancamento`, `nomemid`, `velocidade_leitura`
FROM albumMusica NATURAL JOIN midia
WHERE `nomemid`= 'YouTube';

SELECT `nomealbum`, `banda/cantor`, `ano_lancamento`, `nomemid`, `velocidade_leitura`
FROM albumMusica NATURAL JOIN midia
WHERE `nomemid`= 'Spotify';

-- -----------------------------------------------------
-- Questão 13
-- Pergunta 5
-- -----------------------------------------------------
SELECT `idalbumMusica`, `nomealbum`, `banda/cantor`, `ano_lancamento`, `nomemid`, `velocidade_leitura`
FROM albumMusica NATURAL JOIN midia;