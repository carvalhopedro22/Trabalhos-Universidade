-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema trabalhobdexpandido
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema trabalhobdexpandido
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `trabalhobdexpandido` DEFAULT CHARACTER SET utf8 ;
USE `trabalhobdexpandido` ;

-- -----------------------------------------------------
-- Table `trabalhobdexpandido`.`fabricante`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `trabalhobdexpandido`.`fabricante` (
  `idfabricante` INT NOT NULL,
  `nomefab` VARCHAR(45) NULL,
  `ano_fundacao` INT NULL,
  PRIMARY KEY (`idfabricante`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `trabalhobdexpandido`.`plataforma`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `trabalhobdexpandido`.`plataforma` (
  `idplataforma` INT NOT NULL,
  `nomeplat` VARCHAR(45) NULL,
  `ano_lancamento` INT NULL,
  `memoria` INT NULL,
  `idfabricante` INT NOT NULL,
  PRIMARY KEY (`idplataforma`),
  INDEX `fk_plataforma_fabricante_idx` (`idfabricante` ASC),
  CONSTRAINT `fk_plataforma_fabricante`
    FOREIGN KEY (`idfabricante`)
    REFERENCES `trabalhobdexpandido`.`fabricante` (`idfabricante`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `trabalhobdexpandido`.`midia`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `trabalhobdexpandido`.`midia` (
  `idmidia` INT NOT NULL,
  `nomemid` VARCHAR(45) NULL,
  `velocidade_leitura` INT NULL,
  PRIMARY KEY (`idmidia`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `trabalhobdexpandido`.`compativel_midia`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `trabalhobdexpandido`.`compativel_midia` (
  `idmidia` INT NOT NULL,
  `idplataforma` INT NOT NULL,
  PRIMARY KEY (`idmidia`, `idplataforma`),
  INDEX `fk_compativel_midia_plataforma1_idx` (`idplataforma` ASC),
  CONSTRAINT `fk_compativel_midia_midia1`
    FOREIGN KEY (`idmidia`)
    REFERENCES `trabalhobdexpandido`.`midia` (`idmidia`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_compativel_midia_plataforma1`
    FOREIGN KEY (`idplataforma`)
    REFERENCES `trabalhobdexpandido`.`plataforma` (`idplataforma`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `trabalhobdexpandido`.`jogo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `trabalhobdexpandido`.`jogo` (
  `idjogo` INT NOT NULL,
  `nomejogo` VARCHAR(45) NULL,
  `descricao` VARCHAR(45) NULL,
  PRIMARY KEY (`idjogo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `trabalhobdexpandido`.`compativel_jogo_plataforma`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `trabalhobdexpandido`.`compativel_jogo_plataforma` (
  `quantidade` INT NULL,
  `ano_lancamento_jogo` INT NULL,
  `idplataforma` INT NOT NULL,
  `idjogo` INT NOT NULL,
  PRIMARY KEY (`idplataforma`, `idjogo`),
  INDEX `fk_compativel_jogo_plataforma_jogo1_idx` (`idjogo` ASC),
  CONSTRAINT `fk_compativel_jogo_plataforma_plataforma1`
    FOREIGN KEY (`idplataforma`)
    REFERENCES `trabalhobdexpandido`.`plataforma` (`idplataforma`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_compativel_jogo_plataforma_jogo1`
    FOREIGN KEY (`idjogo`)
    REFERENCES `trabalhobdexpandido`.`jogo` (`idjogo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `trabalhobdexpandido`.`albumMusica`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `trabalhobdexpandido`.`albumMusica` (
  `idalbumMusica` INT NOT NULL,
  `nomealbum` VARCHAR(45) NULL,
  `banda/cantor` VARCHAR(45) NULL,
  `ano_lancamento` INT NULL,
  `idmidia` INT NOT NULL,
  PRIMARY KEY (`idalbumMusica`, `idmidia`),
  INDEX `fk_albumMusica_midia1_idx` (`idmidia` ASC),
  CONSTRAINT `fk_albumMusica_midia1`
    FOREIGN KEY (`idmidia`)
    REFERENCES `trabalhobdexpandido`.`midia` (`idmidia`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
