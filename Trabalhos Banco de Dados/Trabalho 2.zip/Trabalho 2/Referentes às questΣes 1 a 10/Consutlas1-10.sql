USE trabalhobd;
-- -----------------------------------------------------
-- Questão 1
-- -----------------------------------------------------
SELECT `nomeplat`
FROM (plataforma NATURAL JOIN compativel_midia) NATURAL JOIN midia
WHERE `velocidade_leitura` > 100
GROUP BY `nomeplat`;

-- -----------------------------------------------------
-- Questão 2
-- -----------------------------------------------------
SELECT `nomeplat`, `ano_lancamento`
FROM plataforma NATURAL JOIN fabricante 
WHERE `ano_fundacao` > 1970;

-- -----------------------------------------------------
-- Questão 3
-- -----------------------------------------------------
SELECT `nomemid`, `velocidade_leitura`
FROM midia
WHERE `velocidade_leitura` BETWEEN 10 AND 30
ORDER BY `velocidade_leitura` DESC, `nomemid`;

-- -----------------------------------------------------
-- Questão 4
-- -----------------------------------------------------
INSERT INTO `trabalhobd`.`plataforma`
(`idplataforma`, `nomeplat`, `ano_lancamento`, `memoria`, `idfabricante`)
VALUES (7, 'WiiU', 2012, '214743648',
    (SELECT `idfabricante`
    FROM fabricante
    WHERE `nomefab` LIKE 'Nintendo')); 
-- CONSULTA DE TESTE
SELECT * FROM plataforma;

-- -----------------------------------------------------
-- Questão 5
-- -----------------------------------------------------
SELECT `nomeplat`, `nomefab`, COUNT(*) AS numero_jogos
FROM ((compativel_jogo_plataforma NATURAL JOIN jogo) 
NATURAL JOIN plataforma) NATURAL JOIN fabricante
GROUP BY `nomeplat`
ORDER BY `nomeplat`;

-- -----------------------------------------------------
-- Questão 6
-- -----------------------------------------------------
SELECT `nomejogo`
FROM (compativel_jogo_plataforma NATURAL JOIN jogo) 
NATURAL JOIN plataforma
GROUP BY `nomejogo`
HAVING COUNT(*) > 1;

-- -----------------------------------------------------
-- Questão 7
-- -----------------------------------------------------
SELECT COUNT(*) AS jogos_lancados, `ano_lancamento_jogo`
FROM (compativel_jogo_plataforma NATURAL JOIN jogo)
GROUP BY `ano_lancamento_jogo`
ORDER BY `ano_lancamento_jogo`;

-- -----------------------------------------------------
-- Questão 8
-- -----------------------------------------------------
SELECT `nomejogo`, `ano_lancamento_jogo`, `nomeplat`
FROM (compativel_jogo_plataforma AS c1 NATURAL JOIN jogo AS j1) 
NATURAL JOIN plataforma
WHERE `ano_lancamento_jogo` < ALL (
	SELECT `ano_lancamento_jogo`
    FROM compativel_jogo_plataforma AS c2 NATURAL JOIN jogo AS j2
    WHERE c2.idjogo <> c1.idjogo
);

-- -----------------------------------------------------
-- Questão 9
-- -----------------------------------------------------
SELECT AVG(`memoria`)
FROM (compativel_jogo_plataforma  NATURAL JOIN jogo) 
NATURAL JOIN plataforma;

-- -----------------------------------------------------
-- Questão 10
-- -----------------------------------------------------
SELECT `nomefab`
FROM ((compativel_midia NATURAL JOIN midia) NATURAL JOIN plataforma) 
NATURAL JOIN fabricante
GROUP BY `nomefab`
HAVING COUNT(*) > 1
ORDER BY `nomefab`;