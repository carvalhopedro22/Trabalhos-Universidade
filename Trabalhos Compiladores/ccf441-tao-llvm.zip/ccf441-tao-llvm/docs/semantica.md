1. VarType *
2. Yin *
3. Assign *
4. BinaryOp *
5. UnaryOp *
6. If *
7. While *
8. Repeat *
9. Break *
10. Continue *
11. Return *
12. Block *
13. Yang *
14. Call *
15. Address *
16. Malloc *
17. Free *
18. Access
19. TypeDef/Constr
20. Match/Case
21. Decons