#ifndef CODEGEN_H
#define CODEGEN_H

#include <iostream>
#include <llvm/IR/Module.h>
#include <llvm/IR/IRBuilder.h>
#include "defs.hpp"

#endif