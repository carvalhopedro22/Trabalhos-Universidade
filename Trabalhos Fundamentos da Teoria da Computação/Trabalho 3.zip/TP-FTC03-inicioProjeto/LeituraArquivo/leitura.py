from TratamentoDados.tratamentoDados import Transicoes

def leituraArquivo(nomeArquivo):
    arquivo = open(nomeArquivo, "r")
    conteudo = arquivo.readline()
    transicoes = []
    entradas = []

    estados = conteudo.split()
    del (estados[0])
    qtdEstados = len(estados)

    matriz = [[{"Estado": [], "Condicoes": []} for i in range(qtdEstados + 1)] for j in range(qtdEstados + 1)]
    for i in range(1, qtdEstados + 1):
        matriz[0][i]["Estado"].append(estados[i - 1])
        matriz[i][0]["Estado"].append(estados[i - 1])


    conteudo = arquivo.readline()
    alfabeto = conteudo.split()
    del(alfabeto[0])

    conteudo = arquivo.readline()

    inicial = conteudo.split()
    del (inicial[0])

    conteudo = arquivo.readline()

    finais = conteudo.split()
    del (finais[0])

    while conteudo != '---\n':
        conteudo = arquivo.readline()
        transicoes.append(conteudo)

    while conteudo != '':
        conteudo = arquivo.readline()
        if conteudo != '':
            entradas.append(conteudo.replace("\n", ""))

    del (transicoes[-1])
    Transicoes(matriz, transicoes, qtdEstados)

    return matriz,qtdEstados,inicial,finais, entradas