def Transicoes(matriz, transicoes, tamLinhaMatriz):
    for transicao in transicoes:
        transicaoOut = transicao.split(" ")
        partida, final, condicoes = tratamentoTransicao(transicaoOut)
        preencheMatriz(matriz, partida, final, condicoes, tamLinhaMatriz)



def tratamentoTransicao(transicao):
    partida = transicao[0]
    final = transicao[2]
    condicoes = []
    for i in range(4, len(transicao)):
        condicoes.append(transicao[i].replace("\n", ""))

    return partida, final, condicoes


def preencheMatriz(matriz, partida, final, condicoes, tamLinhaMatriz):
    posicaoI = 0
    posicaoF = 0
    for i in range(1, tamLinhaMatriz + 1):
        if matriz[i][0]["Estado"][0] == partida:
            posicaoI = i

        if matriz[0][i]["Estado"][0] == final:
            posicaoF = i

    matriz[posicaoI][posicaoF]["Condicoes"].append(condicoes)