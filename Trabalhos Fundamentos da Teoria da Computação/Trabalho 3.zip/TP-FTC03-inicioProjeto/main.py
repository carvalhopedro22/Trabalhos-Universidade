from LeituraArquivo.leitura import leituraArquivo
from execucaoAutomato import ExecutionAutomato

def main():
    print("""\033[1;31m
     _____ _                 _           _           
    /  ___(_)               | |         | |          
    \ `--. _ _ __ ___  _   _| | __ _  __| | ___  _ __
     `--. \ | '_ ` _ \| | | | |/ _` |/ _` |/ _ \| '__|
    /\__/ / | | | | | | |_| | | (_| | (_| | (_) | |  
    \____/|_|_| |_| |_|\__,_|_|\__,_|\__,_|\___/|_|
    \033[0m""")

    print("""\033[1;36m
       ╔══════════════════════════════╗
       ║ Entre com o nome do arquivo: ║
       ╚══════════════════════════════╝
    \033[0m""")

    nomeArquivo = input(">")
    nomeArquivo += ".txt"
    matriz,qtdEstados,inicial,finais,entradas = leituraArquivo(nomeArquivo)

    for entrada in entradas:
        if(ExecutionAutomato(matriz,qtdEstados,inicial,finais,entrada)):
            print("OK")
        else:
            print("X")


main()

