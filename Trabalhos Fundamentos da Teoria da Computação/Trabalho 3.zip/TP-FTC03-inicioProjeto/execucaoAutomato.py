

def linhasEstadosPartidaFim(matriz,qtdEstados,inicial,finais):
    tamFinais = len(finais)
    Finais = []
    posicaoFinais = 0
    posicaoI = 0

    for i in range(1, qtdEstados + 1):
        if matriz[i][0]["Estado"][0] == inicial[0]:
            posicaoI = i

        if posicaoFinais<tamFinais  and  matriz[0][i]["Estado"][0] == finais[posicaoFinais]:
            Finais.append(i)
            posicaoFinais += 1

    return posicaoI,Finais



def ExecutionAutomato(matriz, qtdEstados, inicial, finais, entrada):
    posicaoInicial,posicoesFinais = linhasEstadosPartidaFim(matriz,qtdEstados,inicial,finais)

    for i in range(len(entrada)):
        posicaoInicial = analisaTransicao(i, matriz, qtdEstados, posicaoInicial, entrada)

        if posicaoInicial == -1:
            return False

    if posicaoInicial in posicoesFinais:
        return True


def analisaTransicao(posicaoEntradas,matriz,qtdEstados,posicaoInicial,entrada):
    for i in range(1,qtdEstados+1):
        condicoes = matriz[posicaoInicial][i]["Condicoes"]

        if condicoes != []:
            for j in range(len(condicoes[0])):

                if condicoes[0][j] == entrada[posicaoEntradas]:
                    return i

    return -1




