from time import time
from random import uniform, random

class HillClimbingOptimizer:
    #construtor
    def __init__(self, z, limits, tweak_size, tweak_prob = 0.5, tweak_n = 5, time_limit = 2, iteration_limit = 100):
        self.z = z
        self.limits = limits
        self.tweak_size = tweak_size
        self.tweak_prob = tweak_prob
        self.tweak_n = tweak_n
        self.time_limit = time_limit
        self.iteration_limit = iteration_limit

    def optimize(self):
        initial_time = time()
        s = self.get_initial_solution()
        z_best = [self.z(s)]
        while not self.stop_condition(initial_time, z_best):
            #vetor das tuplas x e y
            s_next = [self.tweak(s) for _ in range(self.tweak_n)]
            #retorna a tupla com melhor resultado
            s_best = min(s_next + [s], key = self.z) 
            s = s_best
            z_best.append(self.z(s))
        return s

    def get_initial_solution(self):
        return [uniform(xmin, xmax) for xmin, xmax in self.limits]

    # condições de parada - limite de tempo, qtd de iterações sem melhoria
    def stop_condition(self, initial_time, z_best):
        if time() - initial_time > self.time_limit:
            return True
        if len(z_best) <= self.iteration_limit:
            return False
        for i in range(self.iteration_limit):
            current = z_best[-1-i]
            previous = z_best[-2-i]
            if previous / current > 1.001:
                return False 
        return True
    
    def tweak(self, s):
        s = s.copy()
        for i, x in enumerate(s):
            if random() <= self.tweak_prob:
                while True:
                    s[i] = x + uniform(-1, 1) * self.tweak_size[i]
                    if self.limits[i][0] <= s[i] <= self.limits[i][1]:
                        break
        return s