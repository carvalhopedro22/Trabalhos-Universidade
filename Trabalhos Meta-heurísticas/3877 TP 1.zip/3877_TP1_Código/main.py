from math import cos, sin, sqrt
from pickletools import optimize
from hill_climbing import HillClimbingOptimizer
from vns import VNSOptimizer

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

print("""\033[1;36m
╔═════════════════════════════════════════════════╗
║        Opções: Algoritmos e Problemas           ║
╠═════════════════════════════════════════════════╣
║ 1) Problema 1                                   ║
║ 2) Problema 2                                   ║
╚═════════════════════════════════════════════════╝
\033[0m""")

print("""\033[1;36m
╔═════════════════════════════════════════════╗
║ Escolha uma das opções mostradas no quadro! ║
╚═════════════════════════════════════════════╝
\033[0m""")
opcao = int(input())

# PROBLEMA 1: A e B
def z1(s):
    return abs(s[0]**2 + s[1]**2 + s[0]*s[1]) + abs(sin(s[0])) + abs(cos(s[1]))

# PROBLEMA 2: C e D
def z2(s):   
    return 100 * sqrt(abs(s[1] - 0.01 * (s[0]**2))) + 0.01 * abs(s[0] + 10)


def runs(z_label, z, test_labels, optimizers):
    dfs = []
    for test_label, optimizer in zip(test_labels, optimizers):
        s_best = [optimizer.optimize() for i in range(30)]
        data = [(test_label, x, y, z([x,y])) for x, y in s_best]
        df = pd.DataFrame(data, columns = ["label","x", "y", "f"])
        dfs.append(df)

        print(f"""\033[1;36m
        ╔══════════════════════╗
        ║ Algoritmo / Problema ║
        ╚══════════════════════╝
        "═════ {test_label} ═════"
        \033[0m""")

        print("""\033[1;36m
        ╔═════════════════════════════╗
        ║ Resultado das 30 execuções: ║
        ╚═════════════════════════════╝
        \033[0m""")
        print(df)

        print(f"""\033[1;36m
        ╔════════════════════════════╗
        ║ Melhor solução encontrada: ║
        ╚════════════════════════════╝
        \033[0m""")
        print(df.loc[df.f.idxmin()]) # Solução

        print("""\033[1;36m
        ╔═══════════════╗
        ║ Estatísticas: ║
        ╚═══════════════╝
        \033[0m""")
        dataframe1 = df.describe()
        print(dataframe1)
    
    df = pd.concat(dfs, axis=0)
    sns.boxplot(x="label", y="f", data=df)
    plt.title(f"Valores da função objetivo {z_label}")
    plt.savefig(f"boxplot-{z_label}.png")


# Problema 1
if opcao == 1:
    hco1a = HillClimbingOptimizer(z1, [[-500,500], [-500,500]], [10,12], tweak_prob = 1) 
    vns1a = VNSOptimizer(z1, [[-500,500], [-500,500]], [1,10,100,200], tweak_prob = 1) 

    hco1b = HillClimbingOptimizer(z1, [[-10,10], [-20,20]], [1,1], tweak_prob = 1) 
    vns1b = VNSOptimizer(z1, [[-10,10], [-20,20]], [0.01,0.1,1,4,8], tweak_prob = 1)

    optimizers = [hco1a, vns1a, hco1b, vns1b]
    runs("f1", z1, ["HCI A", "RVNS A", "HCI B", "RVNS B"], optimizers)

# Problema 2
if opcao == 2:
    hco2c = HillClimbingOptimizer(z2, [[-15,-5], [-3,3]], [1,1], tweak_prob = 1) 
    vns2c = VNSOptimizer(z2, [[-15,-5], [-3,3]], [0.01,0.1,1,2], tweak_prob = 1)

    hco2d = HillClimbingOptimizer(z2, [[-11,-9], [0,2]], [0.5,0.5], tweak_prob = 1) 
    vns2d = VNSOptimizer(z2, [[-11,-9], [0,2]], [0.01,0.1,1,2], tweak_prob = 1)
    
    optimizers = [hco2c, vns2c, hco2d, vns2d]
    runs("f2", z2, ["HCI C", "RVNS C", "HCI D", "RVNS D"], optimizers)