from time import time
from random import uniform, random

class VNSOptimizer:
    #construtor
    def __init__(self, z, limits, neighborhoods, tweak_prob = 0.5, time_limit = 2, iteration_limit = 100):
        self.z = z
        self.limits = limits
        self.neighborhoods = neighborhoods
        self.tweak_prob = tweak_prob
        self.time_limit = time_limit
        self.iteration_limit = iteration_limit

    def optimize(self):
        initial_time = time()
        s = self.get_initial_solution()
        z_best = [self.z(s)]
        while not self.stop_condition(initial_time, z_best):
            k = 0
            while not k == len(self.neighborhoods):
                s_next = self.tweak(s, k)
                s,k = self.neighborhoodchange(s, s_next, k)
                z_best.append(self.z(s))
        return s

    def neighborhoodchange(self, s, s_next, k):
        if self.z(s_next) < self.z(s):
            return s_next, 1
        else:
            return s, k + 1


    def get_initial_solution(self):
        return [uniform(xmin, xmax) for xmin, xmax in self.limits]

    # condições de parada - limite de tempo, qtd de iterações sem melhoria
    def stop_condition(self, initial_time, z_best):
        if time() - initial_time > self.time_limit:
            return True
        if len(z_best) <= self.iteration_limit:
            return False
        for i in range(self.iteration_limit):
            current = z_best[-1-i]
            previous = z_best[-2-i]
            if previous / current > 1.001:
                return False 
        return True
    
    def tweak(self, s, k):
        s = s.copy()
        for i, x in enumerate(s):
            if random() <= self.tweak_prob:
                while True:
                    s[i] = x + uniform(-1, 1) * self.neighborhoods[k]
                    if self.limits[i][0] <= s[i] <= self.limits[i][1]:
                        break
        return s