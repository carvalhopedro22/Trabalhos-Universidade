from read_file import read_file

if __name__ == "__main__":
    read_file()
    
        
