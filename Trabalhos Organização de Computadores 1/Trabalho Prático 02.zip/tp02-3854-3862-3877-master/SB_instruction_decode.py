from utils import decimal_to_others_bases
from utils import hexadecimal_to_binary
from output_type import output_function

# SB -> immediate(7 bits), rs2, rs1, funct3, immediate(5 bits), opcode

SB_instru = {

    # funct3, opcode
    "beq": ["000", "1100111"],
    "bne": ["001", "1100111"],
    "blt": ["100", "1100111"],
    "bge": ["101", "1100111"]
}

def SB_TypeInstruction(lines):
    varInfo = []
    output = ''
    
    instruInfo = SB_instru[lines[0]]

    varInfo = [lines[1], lines[2], lines[3]]

    ##transforma pra binario automatico
    rs1 = decimal_to_others_bases(int(varInfo[0][1:]), 2)
    rs2 = decimal_to_others_bases(int(varInfo[1][1:]), 2)
    
    if("0x" in varInfo[2]):
        immediate = hexadecimal_to_binary(varInfo[2][2:])

        #caso tenha mais que 13bits ele pega do bit 0 ao 13
        immediate = immediate[len(immediate) - 13:]
    else: 
        immediate = decimal_to_others_bases(int(varInfo[2]), 2, 13)
        

    ##Ignorando o ultimo bit
    immediate = immediate[:len(immediate) - 1]
    
    #Eles tem que ter 5 bits 
    rs1 = (5 - len(rs1)) * "0" + rs1
    rs2 = (5 - len(rs2)) * "0" + rs2
    immediate = (12 - len(immediate)) * "0" + immediate

    # conferir alcance dos immediate
    outputList = [immediate[0], immediate[2:8], rs2, rs1, instruInfo[0], immediate[8:] ,immediate[1], instruInfo[1]]

     # Tranforma a lista em string
    output = output.join(outputList)    
    
    # Passa a string ja em binario para a funcao de saida
    output_function(output)
