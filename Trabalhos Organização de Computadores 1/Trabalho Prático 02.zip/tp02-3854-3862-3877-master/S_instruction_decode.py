from utils import decimal_to_others_bases
from utils import hexadecimal_to_binary
from output_type import output_function


S_instru = {
        # funct3, opcode
    "sd": ["111", "0100011"]
}


def S_TypeInstruction(lines):
    varInfo = []
    output = ''
    
    instruInfo = S_instru[lines[0]]

    if(lines[0] == "sd"):
        split_addr = lines[2].split("(")
        split_addr[1] = split_addr[1].replace(")", "")
        lines[2] = split_addr[1]
        lines.append(split_addr[0])

    varInfo = [lines[1], lines[2], lines[3]]

    ##transforma pra binario automatico
    rs1 = decimal_to_others_bases(int(varInfo[1][1:]), 2)
    rs2 = decimal_to_others_bases(int(varInfo[0][1:]), 2)
    
    #conferir se é hexadecimal, tomar cuidado se negativo tiver sinal
    if("0x" in varInfo[2]):
        immediate = hexadecimal_to_binary(varInfo[2][2:])
    else:
        immediate = decimal_to_others_bases(int(varInfo[2]), 2, 12)

    #Eles tem que ter 5 bits 
    rs1 = (5 - len(rs1)) * "0" + rs1
    rs2 = (5 - len(rs2)) * "0" + rs2
    immediate = (12 - len(immediate)) * "0" + immediate

    # conferir alcance dos immediate
    outputList = [immediate[0:7], rs2, rs1, instruInfo[0], immediate[7:], instruInfo[1]]

     # Tranforma a lista em string
    output = output.join(outputList)    
    
    # Passa a string ja em binario para a funcao de saida
    output_function(output)