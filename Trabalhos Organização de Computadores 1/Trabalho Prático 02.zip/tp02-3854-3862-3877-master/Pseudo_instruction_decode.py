from utils import decimal_to_others_bases
from output_type import output_function

Pseudo_instru = {
    
    # Exemplos livro:
    # li x9, 123 == addi x9, x0, 123
    # mv x10, x11  == addi x10, x11, 0
    # and x9, x10, 15 == andi x9, x10, 15
    "li": "addi",
    "mv": "addi", 
    "and": "andi"
}


def Pseudo_Instructions(lines):

    instruInfo = Pseudo_instru[lines[0]]

    if lines[0] == "li":

        outputList = [instruInfo, lines[1], "x0", lines[2]]

    elif lines[0] == "mv":

        outputList = [instruInfo, lines[1], lines[2], "0"]

    else:

        if "x" not in lines[3]:
            
            outputList = [instruInfo, lines[1], lines[2], lines[3]]
            
        else:
            outputList = [lines]


    # A string original que continha pseudo-instrucoes foi tratada, agora eh
    # retornada para que as outras funcoes a traduzam
    return outputList
