from utils import decimal_to_others_bases
from utils import hexadecimal_to_binary
from output_type import output_function


I_instru = {
            # funct3, opcode
    "addi": ["000", "0010011"],
    "andi": ["111", "0010011"],
    "ori" : ["110", "0010011"],
    "ld" : ["011", "0000011"]
}


def I_TypeInstruction(lines):
    varInfo = []
    output = ''
    
    instruInfo = I_instru[lines[0]]

    if(lines[0] == "ld"):
        split_addr = lines[2].split("(")
        split_addr[1] = split_addr[1].replace(")", "")
        lines[2] = split_addr[1]
        lines.append(split_addr[0])

    varInfo = [lines[1], lines[2], lines[3]]

    ##transforma pra binario automatico
    rs1 = decimal_to_others_bases(int(varInfo[1][1:]), 2)
    rd = decimal_to_others_bases(int(varInfo[0][1:]), 2)
    
    #conferir se é hexadecimal, tomar cuidado se negativo tiver sinal
    if("0x" in varInfo[2]):
        immediate = hexadecimal_to_binary(varInfo[2][2:])
    else:
        immediate = decimal_to_others_bases(int(varInfo[2]), 2, 12)

    #Eles tem que ter 5 bits 
    rs1 = (5 - len(rs1)) * "0" + rs1
    rd = (5 - len(rd)) * "0" + rd
    immediate = (12 - len(immediate)) * "0" + immediate

    # conferir alcance dos immediate
    outputList = [immediate, rs1, instruInfo[0], rd, instruInfo[1]]

     # Tranforma a lista em string
    output = output.join(outputList)    
    
    # Passa a string ja em binario para a funcao de saida
    output_function(output)
