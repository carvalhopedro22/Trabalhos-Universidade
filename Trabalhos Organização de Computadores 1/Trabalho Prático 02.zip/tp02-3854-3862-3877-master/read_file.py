import sys

from R_instruction_decode import R_TypeInstruction
from I_instruction_decode import I_TypeInstruction
from SB_instruction_decode import SB_TypeInstruction
from S_instruction_decode import S_TypeInstruction
from Pseudo_instruction_decode import Pseudo_Instructions

R_instructions = ["add", "sub", "and", "sll", "srl", "or"]
I_instructions = ["addi", "andi", "ori", "ld"]
Sb_instructions = ["beq", "bne", "blt", "bge"]
S_instructions = ["sd"]
Pseudo_instru = ["mv", "and", "li"]

def read_file():
    file_name = sys.argv[1]
    file = open(file_name, 'r')

    ##Gambiarra pra limpar o arquivo caso o output já exista
    if("-o" in sys.argv):
        output_filename = sys.argv[-1]
        open(output_filename, "w")

    # R -> funct7, rs2, rs1, funct3, rd, opcode

    # I -> immediate(12 bits), rs1, funct3, rd, opcode

    # S -> immediate(7 bits), rs2, rs1, funct3, immediate(5 bits), opcode

    for line in file:

        # Retira as virgulas da linha(string) que esta lendo do arquivo no momento 
        line = line.replace(',', '')
        
        # Transforma cada item da linha em uma string
        string = line.split()
        if(line[0] == "\n"):
            continue
        
        ## Se for pseudo transforma, se não não faz nada
        string = Pseudo_Instructions(string) if string[0] in Pseudo_instru else string

        if string[0] in R_instructions:
            R_TypeInstruction(string) 
        elif string[0] in I_instructions:
            I_TypeInstruction(string)
        elif string[0] in Sb_instructions:
            SB_TypeInstruction(string)
        elif string[0] in S_instructions:
            S_TypeInstruction(string)

        
    ##file.close()
