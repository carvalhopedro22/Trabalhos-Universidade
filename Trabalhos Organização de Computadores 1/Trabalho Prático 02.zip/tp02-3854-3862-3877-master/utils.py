##botar algumas funções uteis pra gente aqui

def decimal_to_others_bases(num, base, num_bits = 12):
    print
    if base == 2:
        if(num) >= 0:
            return bin(num)[2:]
        else:
            num = abs(num)
            num = num ^ ((2**num_bits) - 1)
            num += 1
            return bin(num)[2:] 
    elif base == 8:
        return oct(num)[2:]
    elif base == 16:
        return hex(num)[2:]



def hexadecimal_to_binary(num):
    num = num.lower()
    words = {
            "a": 10,
            "b": 11,
            "c": 12,
            "d": 13,
            "e": 14,
            "f": 15
        }

    binary = []
    for i in num:
        if i in words.keys():
            ##Garantir que tenha 4bits
            binary_value = bin(words[i])[2:]
            binary_value = (4 - len(binary_value)) * "0" + binary_value
            
            binary.append(binary_value )
        else:
            ##Garantir que tenha 4bits
            binary_value = bin(int(i))[2:]
            binary_value = (4 - len(binary_value)) * "0" + binary_value
            
            binary.append(binary_value)
    
    return ''.join(binary)