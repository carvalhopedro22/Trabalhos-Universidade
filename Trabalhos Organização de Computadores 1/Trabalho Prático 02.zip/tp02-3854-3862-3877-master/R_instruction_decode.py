from utils import decimal_to_others_bases
from output_type import output_function

R_instru = {
        # funct7, fucnt3, opcode (ordem)

        "add": ["0000000", "000", "0110011"],
        "sub": ["0100000", "000", "0110011"],
        "and": ["0000000", "111", "0110011"],
        "sll": ["0000000", "001", "0110011"],
        "srl": ["0000000", "101", "0110011"],
        "or":  ["0000000", "110", "0110011"]
    }

def R_TypeInstruction(lines):
    varInfo = []
    output = ''

    # Pega o primeiro item da string(linha) do arquivo -> nome da instrucao
    # A partir disso resgata as informacoes da instrucao no dicionario
    instruInfo = R_instru[lines[0]]

    # Cria uma lista com os itens restantes da string(linha) do arquivo 
    varInfo = [lines[1], lines[2], lines[3]] 

    ##transforma pra binario automatico
    rs1 = decimal_to_others_bases(int(varInfo[1][1:]), 2)
    rs2 = decimal_to_others_bases(int(varInfo[2][1:]), 2)
    rd = decimal_to_others_bases(int(varInfo[0][1:]), 2) 

    #Eles tem que ter 5 bits 
    rs1 = (5 - len(rs1)) * "0" + rs1
    rs2 = (5 - len(rs2)) * "0" + rs2
    rd = (5 - len(rd)) * "0" + rd

    # Cria uma lista com a instrucao em binario na ordem correta
    ## Trabalhar nos nomes depois, um pouco confuso no momento
    outputList = [instruInfo[0], rs2, rs1, instruInfo[1], rd, instruInfo[2]] 

    # Tranforma a lista em string
    output = output.join(outputList)    
    
    # No momento mostrando como fica, posteriormente sera escrito no arquivo de saida
    output_function(output)

