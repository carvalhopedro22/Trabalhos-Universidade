import sys 
sys_variables = sys.argv ##todas os comandos, por exemplo: [python, main.py, -o, saida]

def write_output_file(line, file_name):
    f = open(file_name, "a+")
    f.write(line + "\n")
    f.close()

##verifica se tem arquivo de saída ou vai ser pelo terminal
def output_function(line):

    ##se tiver um arquivo output
    if("-o" in sys_variables):
        for i in range(len(sys_variables)):
            if(sys_variables[i] == "-o"): 
                write_output_file(line, sys_variables[i + 1])
                break
    else:
        print(line)

