# Trabalho Prático - O Brasil em Dados
## CCF 425 - INTRODUÇÃO À CIÊNCIA DOS DADOS
## Agrotóxicos no Brasil: análise histórica de aprovação e uso

## Integrantes do grupo

- EF03051 Henrique Santana
- EF03871 Larissa Isabelle
- EF03877 Pedro Cardoso

## Apresentação

[Disponível no Google Drive](https://drive.google.com/file/d/1UejkyDhS8h2-CUa9UNdj8gWVeLbbrZ5F/view?usp=sharing)

## Perguntas preliminares

1. Quantos agrotóxicos foram aprovados por ano?
2. Quantos agrotóxicos de cada tipo foram aprovados por ano?
3. Quais foram os 10 ingredientes mais usados nos agrotóxicos?
4. Quais foram as empresas que mais tiveram agrotóxicos aprovados?
5. Quais foram as empresas que mais tiveram agrotóxicos aprovados a cada ano?
6. Quantos agrotóxicos de cada classificação toxicológica foram aprovados por ano?
7. Quantos agrotóxicos de cada classificação de periculosidade ambiental foram aprovados por ano?
8. Qual a distribuição do tempo de aprovação dos agrotóxicos?
9. Qual a distribuição do tempo de aprovação dos agrotóxicos por ano?
10. Qual a distribuição do tempo de aprovação dos agrotóxicos de cada tipo?
11. Qual a distribuição do tempo de aprovação dos agrotóxicos de cada tipo por período de mandato?
12. Qual a distribuição do tempo de aprovação dos agrotóxicos contendo os 10 ingredientes mais usados?
13. Qual a distribuição do tempo de aprovação dos agrotóxicos solicitados pelas 10 empresas mais frequentes?
14. Qual a distribuição do tempo de aprovação dos agrotóxicos de cada classificação toxicológica?
15. Qual a distribuição do tempo de aprovação dos agrotóxicos de cada classificação toxicológica por período de mandato?
16. Qual a distribuição do tempo de aprovação dos agrotóxicos de cada classificação de periculosidade ambiental?
17. Qual a distribuição do tempo de aprovação dos agrotóxicos de cada classificação de periculosidade ambiental por período de mandato?
18. Quantos agrotóxicos foram aprovados por ano, considerando o ano em que seu registro foi protocolado?
19. Quantos agrotóxicos de cada tipo pertencem a cada classificação toxicológica?
20. Quantos agrotóxicos de cada tipo pertencem a cada classificação de periculosidade ambiental?
21. Quantos agrotóxicos de cada um dos 10 ingredientes mais usados pertencem a cada tipo?
22. Quantos agrotóxicos de cada um dos 10 ingredientes mais usados pertencem a cada classificação toxicológica?
23. Quantos agrotóxicos de cada um dos 10 ingredientes mais usados pertencem a cada classificação de periculosidade ambiental?
24. Quantos agrotóxicos de cada uma das 10 empresas mais frequentes pertencem a cada classificação toxicológica?
25. Quantos agrotóxicos de cada uma das 10 empresas mais frequentes pertencem a cada classificação de periculosidade ambiental?

## Análise Preditiva

Considerando as mudanças observadas no comportamento do conjunto de dados analisado nos últimos anos (de 2016 pra cá), pretendemos avaliar as seguintes questões:

1. Podemos dizer que com certeza a média de aprovação de agrotóxicos mudou de antes de 2016 para depois de 2016?
2. Podemos prever o tempo de aprovação de novos agrotóxicos com base em suas características?
3. A classificação toxicológica mudou no final de 2019. É possível prever qual seria a classificação dos registros mais recentes se a classificação antiga ainda fosse usada?

**Fonte de dados:** [Portal de Dados Abertos Sobre Agrotóxicos](https://dados.contraosagrotoxicos.org/)
