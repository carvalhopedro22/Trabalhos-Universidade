#include "arquivo.h"

/* TRANSFORMA UM .TXT EM UMA STRING
void ArquivoParaString(const char *stringHolder){


    char nomeArquivo[30];
    FILE *fp;
    char texto[10000];

    system("CLS");
    printf("\n\t\t\t\t --------------------------------\n");
    printf("\t\t\t\t|    Digite o nome do arquivo    |\n");
    printf("\t\t\t\t --------------------------------\n\t\t\t\t  >>> ");
    scanf("%s", &nomeArquivo);

    fp = fopen(nomeArquivo, "r");
    if (fp == NULL){
        printf("\n\t\t\t\t \\\\\\\\\\\\\\\\\\\ ERRO \\\\\\\\\\\\\\\\\\\ \n");
        printf("\t\t\t\t        ARQUIVO NAO ENCONTRADO      \n\n");
        printf("\t\t\t\t 1 - Inserir outro texto                           \n");
        printf("\t\t\t\t 0 - Retorna ao menu principal                           \n");
        printf("\t\t\t\t    >>> ");
        scanf("%s", &nomeArquivo);

        if (nomeArquivo[0] == '1'){
            ArquivoParaString(stringHolder);
        }
        return;
    }

    strcat(stringHolder, " ");
    while (fgets(texto, 10000, fp) != NULL){
        strcat(stringHolder, texto);
    }
    strcat(stringHolder, " ");

    fclose(fp);

    system("CLS");
    printf("\t\t\t\t --------------------------------------------------------- \n");
    printf("\t\t\t\t               TEXTO INSERIDO COM SUCESSO!          \n");
    printf("\t\t\t\t --------------------------------------------------------- \n");
    printf("\t\t\t\t 0 - Retorna ao menu principal                           \n");
    printf("\t\t\t\t    >>> ");
    scanf("%s",&nomeArquivo);
    strcpy(nomeArquivo, "");
    return 0;

}
*/
