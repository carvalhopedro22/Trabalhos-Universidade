
Trabalho prático 1 da disciplina de Algoritmos e Estruturas de Dados 2 (AEDS 2).

-> Problema: Comparação entre árvores TRIE (TST) e PATRICIA

  Implementar os TADs Árvore TRIE (TST) e PATRICIA para armazenar palavras de um texto ou dicionário, para fins de comparação em termos de custo computacional das operações de inserção e pesquisa.

---> Grupo TADifícil Superar:
* Leonardo Alvarenga - 3895
* Caio Rocha -
* Pedro Carvalho - 3877
* William Araujo - 3472


---> Fontes:
* <Implementação Árvore TRIE (TST) - https://www.geeksforgeeks.org/ternary-search-tree/>
* <Implementação Árvore PATRICIA - https://github.com/limadanillo/Arv_Patricia>

