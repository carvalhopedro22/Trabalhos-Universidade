// -----------------------------------------
//             UFV - CAF
//      Trabalho Pratico I  - AEDS II
// -----------------------------------------
// Leonardo Alvarenga - leo-alvarenga - 3895
// Caio Rocha - CaioRocha-UFV e RockFall - 3892
// Pedro Carvalho carvalhopedro22 - 3877
// William Araujo WilliamAraujoSCdc - 3472
//___________________________________________

#include "Patricia.h"

// VARIAVEIS GLOBAIS
int compInsercaoPAT = 0;

// Teste se um nó é externo ou não
short isExternal(PointerPAT node) {
    return (node->type == External);
}

// Cria um novo nó interno na árvore
PointerPAT CriarNoInterno(PointerPAT *left, PointerPAT *right, int index, char compare) {
    PointerPAT p;
    p = (PointerPAT)malloc(sizeof(PatriciaNode));
    p->type = Internal;
    p->Node.InternNode.left = *left;
    p->Node.InternNode.right = *right;
    p->Node.InternNode.index = index;
    p->Node.InternNode.compare = compare;
    return p;
}

// Cria um novo nó externo na árvore
PointerPAT CriarNoExterno(String word, PointerPAT *p) {
    *p = (PointerPAT)malloc(sizeof(PatriciaNode));
    (*p)->type = External;
    strcpy((*p)->Node.word, word);
    return *p;
}

// Busca uma dada palavra
short PATRICIABuscarPalavra(String word, PointerPAT tree, int *compPesquisaPAT) {

    if (isExternal(tree)) {
        return (strcmp(word, tree->Node.word) == 0) ? 1 : 0;
    }

    if (strlen(word) < tree->Node.InternNode.index) {
        (*compPesquisaPAT)++;
        return PATRICIABuscarPalavra(word, tree->Node.InternNode.left, compPesquisaPAT);
    } else if (word[tree->Node.InternNode.index] < tree->Node.InternNode.compare) {
        *compPesquisaPAT += 2;
        return PATRICIABuscarPalavra(word, tree->Node.InternNode.left, compPesquisaPAT);
    } else {
        *compPesquisaPAT += 3;
        return PATRICIABuscarPalavra(word, tree->Node.InternNode.right, compPesquisaPAT);
    }
}

// Função interna de inserção, criando os nodes nescessários
PointerPAT InternaInserirNaPATRICIA(String word, PointerPAT *tree, int index, char differentChar) {
    PointerPAT novoNoExt = NULL;

    if (isExternal(*tree)) {
        CriarNoExterno(word, &novoNoExt);

        if (strcmp((*tree)->Node.word, word) < 0) {
            return (CriarNoInterno(tree, &novoNoExt, index, differentChar));
        } else if (strcmp((*tree)->Node.word, word) > 0) {
            return (CriarNoInterno(&novoNoExt, tree, index, differentChar));
        }

        return NULL;
    } else if (index < (*tree)->Node.InternNode.index) {
        CriarNoExterno(word, &novoNoExt);

        if (word[index] < differentChar) {
            return (CriarNoInterno(&novoNoExt, tree, index, differentChar));
        } else {
            return (CriarNoInterno(tree, &novoNoExt, index, differentChar));
        }
    } else {
        int indexChanged = (*tree)->Node.InternNode.index;

        if (word[indexChanged] < (*tree)->Node.InternNode.compare) {
            compInsercaoPAT += 1;
            (*tree)->Node.InternNode.left = InternaInserirNaPATRICIA(word, &(*tree)->Node.InternNode.left, index, differentChar);
        } else {
            compInsercaoPAT += 2;
            (*tree)->Node.InternNode.right = InternaInserirNaPATRICIA(word, &(*tree)->Node.InternNode.right, index, differentChar);
        }

        return (*tree);
    }
}

// Insere uma palavra na PATRICIA
PointerPAT PATRICIAInserirPalavra(String word, PointerPAT *tree) {

    if (*tree == NULL) {
        return (CriarNoExterno(word, tree));
    } else {
        PointerPAT p = *tree;
        int index;
        int lastIndex = 0;

        while (!isExternal(p)) {
            lastIndex = p->Node.InternNode.index;

            if (word[p->Node.InternNode.index] < p->Node.InternNode.compare){
                compInsercaoPAT += 1;
                p = p->Node.InternNode.left;
            }
            else if (word[p->Node.InternNode.index] >= p->Node.InternNode.compare){
                compInsercaoPAT += 2;
                p = p->Node.InternNode.right;
            }
            else{
                compInsercaoPAT += 3;
                p = p->Node.InternNode.left;
            }
        }

        if (strcmp(p->Node.word, word) == 0) {
            printf("\n\t\t\t\t ## A chave ja estava na arvore ##\n");
            return (*tree);
        } else {
            /**
             * Trecho da função baseado no trio - Vitor Luís, Lucas Duarte e Vinícius Gabriel
             * Copyright © 2018 UFV Florestal. All rights reserved.
             */
            char charDif;

            // Verifica qual palavra é a menor
            int lowerSize = (strlen(word) < strlen(p->Node.word)) ? strlen(word) : strlen(p->Node.word);

            for (index = 0; index <= lowerSize; index++) {
                if (word[index] != p->Node.word[index]) {
                    compInsercaoPAT += 1;
                    if (word[index] < p->Node.word[index]) {
                        compInsercaoPAT += 1;
                        charDif = p->Node.word[index];
                        break;
                    } else {
                        compInsercaoPAT += 2;
                        charDif = word[index];
                        break;
                    }
                }
            }

            return InternaInserirNaPATRICIA(word, tree, index, charDif);
        }
    }
}

// Printa todas as palavras em ordem alfabetica
void PrintaAPatricia(PointerPAT tree) {
    if (tree != NULL) {
        if (tree->type == Internal)
            PrintaAPatricia(tree->Node.InternNode.left);
        if (tree->type == External)
            printf("\t\t\t\t%s\n", tree->Node.word);
        if (tree->type == Internal)
            PrintaAPatricia(tree->Node.InternNode.right);
    }
}

// Imprime o numero de comparações de inserção
void NumeroDeComparacoesPAT(PointerPAT raiz) {
    printf("\n\t\t\t--> Numero total de comparacoes para insercao na PATRICIA: %d\n", compInsercaoPAT);
    compInsercaoPAT = 0;
}

// Insere as palavras do texto dado na PATRICIA
void PATRICIAInserirTexto (const char *texto, PointerPAT **raiz){

        // SE O TEXTO ESTA VAZIO, PRINTA E RETORNA
    if (TextoVazio(texto)){
        OTextoEstaVazio();
        return;
    }

    // Inicia a TST
    //*raiz) = inicializaPAT();
    **raiz = NULL;

    // Variaveis
    char palavra[50];
    char arrayDePalavras[10000][50];
    char aux[30];

    strcpy(palavra, "");

    // Flag que indica que estamos atualmente dentro de uma palavra
    int addingWord = 0;

    // -------------- TIMER ------------------
    LARGE_INTEGER frequency;        // ticks per second
    LARGE_INTEGER t1, t2;           // ticks
    double elapsedTime;
    // get ticks per second
    QueryPerformanceFrequency(&frequency);
    // start timer
    QueryPerformanceCounter(&t1);
    // -------------- TIMER ------------------


    // LOOP PARA INDENTIFICAR AS PALAVRAS
    for (int i = 1; texto[i] != '\0';i++)
    {
        char currentChar[1];
        currentChar[0] = tolower(texto[i]);

        // IF acabamos de entrar em uma nova palavra
        if (texto[i] != ' ' && texto[i-1] == ' '){
            addingWord = 1; // FLAG = 1
        }

        // ELSE IF chegamos no final de uma palavra
        else if (texto[i] == ' '){
            addingWord = 0; // FLAG = 0
        }


        if (addingWord == 0){ // IF nao estamos em uma palavra -> Palavra completa
            // Adicionamos a palavra à arvore

            //inserirPAT(palavra, (*raiz));
            **raiz = PATRICIAInserirPalavra(palavra, *raiz);


            strcpy(palavra, ""); // reseta palavra

        } else{ // ELSE estamos em uma palavra
            if (strcmp(currentChar, ".") != 0 && strcmp(currentChar, ",") != 0 && strcmp(currentChar, ";") != 0 && strcmp(currentChar, "|") != 0 ){
                strcat(palavra, currentChar); // ADD palavra

            }
        }
    }

        // stop timer
    QueryPerformanceCounter(&t2);
    // compute and print the elapsed time in millisec
    elapsedTime = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;

    system("CLS");
    printf("\t\t\t\t --------------------------------------------------------- \n");
    printf("\t\t\t\t                TEXTO INSERIDO NA PATRICIA!          \n");
    printf("\t\t\t\t --------------------------------------------------------- \n");
    NumeroDeComparacoesPAT(**raiz);
    printf("\t\t\t--> Tempo gasto na insercao da PATRICIA: %f\n", elapsedTime);
    printf("\n\n\t\t\t\t 0 - Retorna ao menu principal                           \n");
    printf("\t\t\t\t    >>> ");
    scanf("%s",&aux);

}
