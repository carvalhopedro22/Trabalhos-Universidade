// -----------------------------------------
//             UFV - CAF
//      Trabalho Pratico I  - AEDS II
// -----------------------------------------
// Leonardo Alvarenga - leo-alvarenga - 3895
// Caio Rocha - CaioRocha-UFV e RockFall - 3892
// Pedro Carvalho carvalhopedro22 - 3877
// William Araujo WilliamAraujoSCdc - 3472
//___________________________________________

#ifndef TP1_AEDS2_PATRICIA_H
#define TP1_AEDS2_PATRICIA_H

#include "../assets/auxiliar.h"
#include <string.h>

#define D 8
#define MAX_SIZE 50

typedef char String[MAX_SIZE];
typedef short StringIndex;
typedef struct PatriciaNode *PointerPAT;
typedef enum {
    Internal,
    External
} PatriciaNodeType;
typedef struct PatriciaNode {
    PatriciaNodeType type;
    union {
        struct {
            StringIndex index;
            char compare;
            PointerPAT left, right;
        } InternNode;

        String word;
    } Node;
} PatriciaNode;
/*

 // Testa se um n� � externo ou n�o
short isExternal(PointerPAT node);

// Cria um novo n� interno
PointerPAT CriarNoInterno(PointerPAT *left, PointerPAT *right, int index, char compare);

// Cria um novo n� externo
PointerPAT CriarNoExterno(String word, PointerPAT *p);

// Busca uma dada palavra
short PATRICIABuscarPalavra(String word, PointerPAT tree, int *compPesquisaPAT);

// Fun��o interna de inser��o, criando os nodes nescess�rios
PointerPAT InternaInserirNaPATRICIA(String word, PointerPAT *tree, int index, char differentChar);

// Insere uma palavra na PATRICIA
PointerPAT PATRICIAInserirPalavra(String word, PointerPAT *tree);

// Printa todas as palavras em ordem alfabetica
void PrintaAPatricia(PointerPAT tree);

// Imprime o numero de compara��es de inser��o
void NumeroDeComparacoesPAT(PointerPAT raiz);

// Insere as palavras do texto dado na PATRICIA
void PATRICIAInserirTexto (const char *texto, PointerPAT **raiz);
*/
#endif //TP1_AEDS2_PATRICIA_H
