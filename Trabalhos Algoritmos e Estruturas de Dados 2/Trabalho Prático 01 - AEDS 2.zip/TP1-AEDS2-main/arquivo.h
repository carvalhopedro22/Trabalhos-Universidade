#ifndef ARQUIVO_H_INCLUDED
#define ARQUIVO_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

//void ArquivoParaString(const char *stringHolder);

#endif // ARQUIVO_H_INCLUDED
