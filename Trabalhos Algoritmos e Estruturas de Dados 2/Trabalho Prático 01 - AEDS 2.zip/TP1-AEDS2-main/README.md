# TP1-AEDS2

Trabalho prático 1 da disciplina de Algoritmos e Estruturas de Dados 2 (AEDS 2).

# Problema: Comparação entre árvores TRIE (TST) e PATRICIA

  Implementar os *TADs* Árvore *TRIE (TST)* e *PATRICIA* para armazenar palavras de um texto ou dicionário, para fins de comparação em termosdo custo computacional das operações de inserção e pesquisa.

## Tarefas:

* Criar uma árvore TRIE (TST) e uma árvore PATRICIA para armazenaras palavras de um texto ou dicionário à escolha do grupo. No caso dese usar o texto, recomenda-se   transformar   as   palavras   paraminúsculas antes da inserção nas árvores. Recomenda-se ainda usardicionário e/ou texto em inglês para evitar acentuação. 
* Para a árvore PATRICIA, adaptar os algoritmos fornecidos em sala de aula para permitir o armazenamento de palavras. A solução mais comum é inserir mais um campo de comparação em cada nó, ouseja, além do campo de índice (que avança x posições na palavra)será necessário também ter um campo com o caracter que estásendo comparado naquela posição para se decidir o caminho a seguir (esquerda ou direita). A decisão de se colocar, no nó interno, o menor ou o maior caracter de comparação e se os iguais ficarão à esquerdaou à direita deste  nó, deverá levar em conta o melhor uso de memória e a diferença de tamanho entre as palavras. 
* Cada   árvore   conterá   apenas   uma   ocorrência   de   cada   palavrainserida, não sendo permitida a inserção de palavras iguais nemsendo necessário registrar o número de ocorrências das palavras notexto (quando for o caso). 
* A estrutura da árvore TRIE TST está diretamente relacionada às primeiras chaves inseridas. Portanto, para o armazenamento dechaves de um dicionário, os testes devem considerar cenários ondeas chaves são inseridas também em ordem aleatória e não apenasem ordem alfabética. Replicar os cenários para PATRICIA, para fins decomparação. 
* Usar  cenários que permitam avaliar a escalabilidade (falta de) da árvore PATRICIA para palavras com mesmo radical e que se diferemem um mesmo caracter. Para o caso de se usar o texto como fontede dados, inserir palavras extras que permitam esse teste já que aprobabilidade   dessas   palavras   estarem   no  texto,   desta forma, é baixa. As mesmas inserções devem ser feitas na TRIE TST para finsde comparação.6.Os testes objetivam comparar as estruturas quanto aos seguintes parâmetros e cenários: uso de memória, tempo de execução enúmero   de   comparações   para   as   operações   de   inserção(Palavra JÁ EXISTE ou NÃO) e pesquisa (COM e SEM sucesso). 
* Todos os testes devem ser realizados em uma mesma máquina, cujaconfiguração deve ser informada no relatório. 
* Elaborar um relatório sintético, contendo: uma introdução, com oobjetivo   do   trabalho   e   as   principais   fontes   (referências)   dosalgoritmos   utilizados;   uma   seção   de   desenvolvimento,   com   osdetalhes da implementação, os testes realizados e a análise dosresultados; e uma seção de considerações finais.
* Na subseção de implementação, explicar em linhas gerais osalgoritmos utilizados e as adaptações realizadas para as operaçõesde inserção e pesquisa, podendo inserir alguns pequenos trechos de código na explicação. Demais detalhes de implementação das estruturas devem ser documentados no próprio código.
* Os testes devem ser apresentados em tabelas e gráficos (quando aplicável), agrupados segundo cada cenário utilizado e que permitama comparação entre as estruturas. 
* O menu de opções do programa deverá conter as seguintesopções: 
  1) escolher árvore, 
  2) inserir palavra, 
  3) pesquisar palavra, 
  4) exibir todas as palavras em ordem alfabética,
  5) contar palavras.
* Para as operações de inserção e pesquisa, exibir uma mensagemcom o número de comparações realizadas.

## Grupo TADifícil Superar:
* [Leonardo Alvarenga](https://github.com/leo-alvarenga) - 3895
* [Caio Rocha](https://github.com/CaioRocha-UFV) - 3892
* [Pedro Carvalho](https://github.com/carvalhopedro22) - 3877
* [William Araujo](https://github.com/WilliamAraujoSCdc) - 3472



## Fontes:
* [Implementação Árvore TRIE (TST)](https://www.geeksforgeeks.org/ternary-search-tree/)
* [Implementação Árvore PATRICIA](https://github.com/limadanillo/Arv_Patricia)
