// -----------------------------------------
//             UFV - CAF
//      Trabalho Pratico I  - AEDS II
// -----------------------------------------
// Leonardo Alvarenga - leo-alvarenga - 3895
// Caio Rocha - CaioRocha-UFV e RockFall - 3892
// Pedro Carvalho carvalhopedro22 - 3877
// William Araujo WilliamAraujoSCdc - 3472
//___________________________________________

#include "menu.h"
#include "arquivo.h"
#include "TST/TST.h"
#include "PATRICIA/PATRICIA.h"

// Menu Principal
void imprimeMenu() {
    int opcao;
    opcao = 10;
    char palavra[30];
    char texto[10000] = "";

    PointerTST *raizTST;
    PointerPAT *raizPAT;

    do{
        system("CLS");
        printf("\t\t\t\t --------------------------------------------------------- \n");
        printf("\t\t\t\t|                       UFV - CAF                         |\n");
        printf("\t\t\t\t|            Trabalho Pratico I  - AEDS II                |\n");
        printf("\t\t\t\t|_________________________________________________________|\n");
        printf("\t\t\t\t|            Caio Rocha             -  3892               |\n");
        printf("\t\t\t\t|            Leonardo Alvarenga     -  3895               |\n");
        printf("\t\t\t\t|            Pedro Carvalho         -  3877               |\n");
        printf("\t\t\t\t|            William Araujo         -  3472               |\n");
        printf("\t\t\t\t --------------------------------------------------------- \n");
        printf("\n\t\t\t\t --------------------------------------------------------- \n");
        printf("\t\t\t\t|                    MENU PRINCIPAL                       |\n");
        printf("\t\t\t\t|                                                         |\n");
        printf("\t\t\t\t|  1 - Escolher arvore:                                   |\n");
        printf("\t\t\t\t|  2 - Inserir palavra no texto:                          |\n");
        printf("\t\t\t\t|  3 - Contar palavras:                                   |\n");
        printf("\t\t\t\t|  4 - Exibir Texto:                                      |\n");
        printf("\t\t\t\t|  5 - Inserir texto a partir de um arquivo:              |\n");
        printf("\t\t\t\t|  0 - Sair                                               |\n");
        printf("\t\t\t\t --------------------------------------------------------- \n");

        printf("\t\t\t\tEntre com uma opcao: ");
        scanf("%d",&opcao);

        switch(opcao){
            case 1: // ESCOLHE ARVORE
                EscolherArvore(&texto, raizTST, raizPAT);
                break;
            case 2: // ADICIONA PALAVRA
                system("CLS");
                while(strcmp(palavra, "0")){
                    printf("\n\t\t\t\t --------------------------------------------------------- \n");
                    printf("\t\t\t\t|             Digite a palavra a ser inserida             |\n");
                    printf("\t\t\t\t|                                                         |\n");
                    printf("\t\t\t\t| 0 - Retorna ao menu principal                           |\n");
                    printf("\t\t\t\t --------------------------------------------------------- \n");
                    printf("\t\t\t\t  >>> ");
                    scanf("%s",&palavra);
                    if (strcmp(palavra, "0") != 0){
                    InserirPalavra(&palavra, &texto);
                    }

                }//fim while
                system("CLS");
                strcpy(palavra, "");
                break;
            case 6: // REMOVE PALAVRA
                system("CLS");
                while(strcmp(palavra, "0")){
                    printf("\n\t\t\t\t --------------------------------------------------------- \n");
                    printf("\t\t\t\t|             Digite a palavra a ser removida             |\n");
                    printf("\t\t\t\t|                                                         |\n");
                    printf("\t\t\t\t| 0 - Retorna ao menu principal                           |\n");
                    printf("\t\t\t\t --------------------------------------------------------- \n");
                    printf("\t\t\t\t  >>> ");
                    scanf("%s",&palavra);
                    if (strcmp(palavra, "0") != 0){
                        RemoverPalavra(&palavra);
                    }

                }//fim while
                system("CLS");
                strcpy(palavra, "");
                break;
            case 3: // CONTAGEM DE PALAVRAS
                ContaPalavras(&texto);
                break;
            case 4: // PRINTA O TEXTO
                PrintarTexto(&texto);  // TEXTO � PRINTADO AQUI
                break;
            case 5: // INSERIR TEXTO DE UM ARQUIVO
                ArquivoParaString(&texto);
                break;
         }//fim switch
    }while(opcao != 0);//fim do do while
}//fim imprimeMenu

// Menus das Arvores
void EscolherArvore(const char *texto, PointerTST *raizTST, PointerPAT *raizPAT){
    int option = 10;
    int treeSelected = 10;
    char aux[30];
    char palavra[30];


            // ESCOLHA DE ARVORE
        system("CLS");
        printf("\t\t\t\t --------------------------------------------------------- \n");
        printf("\t\t\t\t|       Escolha a arvore com a qual quer trabalhar        |\n");
        printf("\t\t\t\t --------------------------------------------------------- \n");
        printf("\t\t\t\t|        Arvore TST                 Arvore PATRICIA       |\n");
        printf("\t\t\t\t|            1                             2              |\n");
        printf("\t\t\t\t|                                                         |\n");
        printf("\t\t\t\t| 0 - Retorna ao menu anterior                            |\n");
        printf("\t\t\t\t ---------------------------------------------------------\n");
        printf("\t\t\t\tEntre com uma opcao: ");
        scanf("%d",&treeSelected);

        if (treeSelected == 0){
            return;
        }
            // OPCAO ERRADA
        if (treeSelected != 1 && treeSelected != 2){
            system("CLS");
            printf("\n\t\t\t\t \\\\\\\\\\\\\\\\\\\ ERRO \\\\\\\\\\\\\\\\\\\\n");
            printf("\t\t\t\t             ENTRADA NAO INDENTIFICADA      \n");
            printf("\t\t\t\t 0 - Retorna a arvore                           \n");
            printf("\t\t\t\t    >>> ");
        }

        do {
                // TST
            if (treeSelected == 1){
                system("CLS");
                printf("\t\t\t\t --------------------------------------------------------- \n");
                printf("\t\t\t\t|                       ARVORE TST                        |\n");
                printf("\t\t\t\t --------------------------------------------------------- \n");
                printf("\t\t\t\t|                                                         |\n");
                printf("\t\t\t\t|  1 - Inserir texto na arvore:                           |\n");
                printf("\t\t\t\t|  2 - Exibir todas as palavras em ordem alfabetica:      |\n");
                printf("\t\t\t\t|  3 - Pesquisar Palavra:                                 |\n");
                printf("\t\t\t\t|  4 - Contar palavras:                                   |\n");
                printf("\t\t\t\t|  5 - Inserir palavra:                                   |\n");
                printf("\t\t\t\t|  0 - Sair                                               |\n");
                printf("\t\t\t\t --------------------------------------------------------- \n");
                printf("\t\t\t\tEntre com uma opcao: ");
                scanf("%d",&option);
            }
                // PATRICIA
            else if (treeSelected == 2){
                system("CLS");
                printf("\t\t\t\t --------------------------------------------------------- \n");
                printf("\t\t\t\t|                     ARVORE PATRICIA                     |\n");
                printf("\t\t\t\t --------------------------------------------------------- \n");
                printf("\t\t\t\t|                                                         |\n");
                printf("\t\t\t\t|  1 - Inserir texto na arvore:                           |\n");
                printf("\t\t\t\t|  2 - Exibir todas as palavras em ordem alfabetica:      |\n");
                printf("\t\t\t\t|  3 - Pesquisar Palavra:                                 |\n");
                printf("\t\t\t\t|  4 - Contar palavras:                                   |\n");
                printf("\t\t\t\t|  5 - Inserir palavra:                                   |\n");
                printf("\t\t\t\t|  0 - Sair                                               |\n");
                printf("\t\t\t\t --------------------------------------------------------- \n");
                printf("\t\t\t\tEntre com uma opcao: ");
                scanf("%d",&option);
            }

                    // ACOES
            switch(option){
                case 1: // INSERE TEXTO NA ARVORE
                    if (treeSelected == 1){
                        // TST
                        TSTInserirTexto(texto, &raizTST);

                    } else if (treeSelected == 2){
                        // PATRICIA
                        PATRICIAInserirTexto(texto, &raizPAT);
                    }
                    break;
                case 2: // EXIBE O TEXTO
                    if (treeSelected == 1){
                        printf("\t\t\t\t---------- TEXTO NA TST ---------");
                        TraverseTST(*raizTST);
                        printf("\t\t\t\t 0 - Retornar                           \n");
                        printf("\t\t\t\t    >>> ");
                        scanf("%s",&aux);
                    } else if (treeSelected == 2) {
                        printf("\t\t\t\t---------- TEXTO NA PATRICIA ---------");
                        PrintaAPatricia(*raizPAT);
                        printf("\t\t\t\t 0 - Retornar                           \n");
                        printf("\t\t\t\t    >>> ");
                        scanf("%s",&aux);
                    }
                    break;
                case 3: // PESQUISA DE PALAVRA
                        if (treeSelected == 1){
                            PesquisaNaTST(*raizTST);

                        } else if (treeSelected == 2){
                            PesquisaNaPAT(*raizPAT);
                        }
                    break;
                case 4:  // CONTA AS PALAVRAS
                    ContaPalavras(texto);
                    break;

                case 5:

                    printf("\n\t\t\t\t --------------------------------------------------------- \n");
                    printf(  "\t\t\t\t|        Digite a palavra a ser inserida na arvore        |\n");
                    printf(  "\t\t\t\t|                                                         |\n");
                    printf(  "\t\t\t\t| 0 - Retornar                                            |\n");
                    printf(  "\t\t\t\t --------------------------------------------------------- \n");
                    printf(  "\t\t\t\t  >>> ");
                    scanf("%s",&palavra);
                    if (strcmp(palavra, "0") != 0){
                        if (treeSelected == 1){
                            // -------------- TIMER ------------------
                            LARGE_INTEGER frequency;        // ticks per second
                            LARGE_INTEGER t1, t2;           // ticks
                            double elapsedTime;

                            int comparacoes = 0;
                            int resultado = searchTST(*raizTST, palavra, &comparacoes);

                            // get ticks per second
                            QueryPerformanceFrequency(&frequency);
                            // start timer
                            QueryPerformanceCounter(&t1);
                            // -------------- TIMER ------------------

                            insert(raizTST, palavra);
                            // stop timer
                            QueryPerformanceCounter(&t2);
                            // compute and print the elapsed time in millisec
                            elapsedTime = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;


                            if (resultado == 1){
                                printf("\n\t\t\t\t ### A palavra ja existia na arvore ###\n");
                            }
                            if (resultado == 0){
                                printf("\n\t\t\t\t --- Palavra adicionada com sucesso! ---\n");
                            }

                            // stop timer
                            QueryPerformanceCounter(&t2);
                            // compute and print the elapsed time in millisec
                            elapsedTime = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;
                            printf("\t\t\t\t ------------------------------------------");
                            printf("\n\t\t\t\t --> Num de comparacoes: %d", comparacoes);
                            printf("\n\t\t\t\t  --> Tempo de Insercao: %f", elapsedTime);

                        } else if (treeSelected == 2){
                            // -------------- TIMER ------------------
                            LARGE_INTEGER frequency;        // ticks per second
                            LARGE_INTEGER t1, t2;           // ticks
                            double elapsedTime;
                            // get ticks per second
                            QueryPerformanceFrequency(&frequency);
                            // start timer
                            QueryPerformanceCounter(&t1);
                            // -------------- TIMER ------------------

                            *raizPAT = PATRICIAInserirPalavra(palavra, raizPAT);

                            // stop timer
                            QueryPerformanceCounter(&t2);
                            // compute and print the elapsed time in millisec
                            elapsedTime = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;
                            printf("\t\t\t\t ------------------------------------------");
                            printf("\n\t\t\t\t --> Tempo de Insercao: %f", elapsedTime);
                            NumeroDeComparacoesPAT(*raizPAT);
                        }

                        printf("\n\t\t\t\t ------------------------------------------\n\t\t\t\t   >>> ");
                        scanf("%s", &palavra);
                    }
                    break;
            }


        }while (option != 0);
}

// PESQUISA NA TST
void PesquisaNaTST(PointerTST raiz){
    char palavra[30];
    int resultado;

    system("CLS");
    printf("\n\t\t\t\t --------------------------------------------------------- \n");
    printf(  "\t\t\t\t|             Digite a palavra a ser pesquisada           |\n");
    printf(  "\t\t\t\t|                                                         |\n");
    printf(  "\t\t\t\t| 0 - Retorna ao menu principal                           |\n");
    printf(  "\t\t\t\t --------------------------------------------------------- \n");
    printf("\t\t\t\t  >>> ");
    scanf("%s",&palavra);

    if (strcmp(palavra, "0") != 0){

        // -------------- TIMER ------------------
        LARGE_INTEGER frequency;        // ticks per second
        LARGE_INTEGER t1, t2;           // ticks
        double elapsedTime;
        // get ticks per second
        QueryPerformanceFrequency(&frequency);
        // start timer
        QueryPerformanceCounter(&t1);
        // -------------- TIMER ------------------

        int comparacoes = 0;
        int resultado = searchTST(raiz, palavra, &comparacoes);

        // stop timer
        QueryPerformanceCounter(&t2);
        // compute and print the elapsed time in millisec
        elapsedTime = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;


        system("CLS");
        if (resultado == 0){
            printf("\n\t\t\t\t ######################################################### \n");
            printf("\t\t\t\t              Palavra NAO encontrada na TST :(         \n");
            printf("\t\t\t\t        Uso de memoria:        %s                            \n", "ToDo");
            printf("\t\t\t\t        Tempo de pesquisa:     %Lf                             \n", elapsedTime);
            printf("\t\t\t\t        Numero de comparacoes: %d                              \n", comparacoes);
            printf(  "\t\t\t\t ######################################################### \n");
        } else if (resultado == 1){
            printf("\n\t\t\t\t --------------------------------------------------------- \n");
            printf("\t\t\t\t                  Palavra encontrada na TST!          \n");
            printf("\t\t\t\t        Uso de memoria:        %s                            \n", "ToDo");
            printf("\t\t\t\t        Tempo de pesquisa:     %f                             \n", elapsedTime);
            printf("\t\t\t\t        Numero de comparacoes: %d                              \n", comparacoes);
            printf(  "\t\t\t\t --------------------------------------------------------- \n");
        }

        printf("\n\t\t\t\t 0 - Retornar                           \n");
        printf("\t\t\t\t    >>> ");
        scanf("%s",&palavra);
/*
        printf("\n\t\t\t\tProcurando (%s) -> resultado: %d\n", palavra, searchTST(raiz, palavra, &comparacoes));
        printf("\t\t\t\t    >>> ");
        scanf("%s",&palavra);*/
    }

}

// PESQUISA NA PATRICIA
void PesquisaNaPAT(PointerPAT raiz){
    char palavra[30];
    int resultado;

    system("CLS");
    printf("\n\t\t\t\t --------------------------------------------------------- \n");
    printf(  "\t\t\t\t|             Digite a palavra a ser pesquisada           |\n");
    printf(  "\t\t\t\t|                                                         |\n");
    printf(  "\t\t\t\t| 0 - Retorna ao menu principal                           |\n");
    printf(  "\t\t\t\t --------------------------------------------------------- \n");
    printf("\t\t\t\t  >>> ");
    scanf("%s",&palavra);

    if (strcmp(palavra, "0") != 0){

        // -------------- TIMER ------------------
        LARGE_INTEGER frequency;        // ticks per second
        LARGE_INTEGER t1, t2;           // ticks
        double elapsedTime;
        // get ticks per second
        QueryPerformanceFrequency(&frequency);
        // start timer
        QueryPerformanceCounter(&t1);
        // -------------- TIMER ------------------

        int comparacoes = 0;
        int resultado = PATRICIABuscarPalavra(palavra, raiz, &comparacoes);

        // stop timer
        QueryPerformanceCounter(&t2);
        // compute and print the elapsed time in millisec
        elapsedTime = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;


        system("CLS");
        if (resultado == 0){
            printf("\n\t\t\t\t ######################################################### \n");
            printf("\t\t\t\t           Palavra NAO encontrada na PATRICIA :(         \n");
            printf("\t\t\t\t        Uso de memoria:        %s                            \n", "ToDo");
            printf("\t\t\t\t        Tempo de pesquisa:     %f                             \n", elapsedTime);
            printf("\t\t\t\t        Numero de comparacoes: %d                              \n", comparacoes);
            printf(  "\t\t\t\t ######################################################### \n");
        } else if (resultado == 1){
            printf("\n\t\t\t\t --------------------------------------------------------- \n");
            printf("\t\t\t\t               Palavra encontrada na PATRICIA!          \n");
            printf("\t\t\t\t        Uso de memoria:        %s                            \n", "ToDo");
            printf("\t\t\t\t        Tempo de pesquisa:     %Lf                             \n", elapsedTime);
            printf("\t\t\t\t        Numero de comparacoes: %d                              \n", comparacoes);
            printf(  "\t\t\t\t --------------------------------------------------------- \n");
        }

        printf("\n\t\t\t\t 0 - Retornar                           \n");
        printf("\t\t\t\t    >>> ");
        scanf("%s",&palavra);
    }

}

// TODO ADICIONA UMA PALAVRA AO TEXTO
void InserirPalavra(const char *palavraASerInserida, const char *texto){
    strcat(texto, " ");
    strcat(texto, palavraASerInserida);
    printf("\n\t\t\t\t-> Palavra \"%s\" inserida com sucesso!\n", palavraASerInserida);
}

// TODO REMOVE UMA PALAVRA DO TEXTO
void RemoverPalavra(const char *palavraASerRemovida) {
        printf("\t\t\t\t-> Palavra \"%s\" removida com sucesso!", palavraASerRemovida);
}

// PRINTA NA TELA O TEXTO ATUAL
void PrintarTexto(const char *texto){
    char aux[10];

    if (TextoVazio(texto)){
        OTextoEstaVazio();
    } else {
        system("CLS");
        printf("\n\t\t\t\t --------------------------------------------------------- \n");
        printf("\n\t\t\t\t                      TEXTO ARMAZENADO: \n\n");
        printf("\t\t\t\t%s", texto);
        printf("\n\t\t\t\t --------------------------------------------------------- \n");
        printf("\t\t\t\t 0 - Retornar                           \n");
        printf("\t\t\t\t    >>> ");
        scanf("%s",&aux);
    }
}

// TRANSFORMA UM .TXT EM UMA STRING
void ArquivoParaString(const char *stringHolder){

    char nomeArquivo[30];
    FILE *fp;
    char texto[10000];

    system("CLS");
    printf("\n\t\t\t\t --------------------------------\n");
    printf("\t\t\t\t|    Digite o nome do arquivo    |\n");
    printf("\t\t\t\t --------------------------------\n\t\t\t\t  >>> ");
    scanf("%s", &nomeArquivo);

    fp = fopen(nomeArquivo, "r");
    if (fp == NULL){
        printf("\n\t\t\t\t \\\\\\\\\\\\\\\\\\\ ERRO \\\\\\\\\\\\\\\\\\\ \n");
        printf("\t\t\t\t        ARQUIVO NAO ENCONTRADO      \n\n");
        printf("\t\t\t\t 1 - Inserir outro texto                           \n");
        printf("\t\t\t\t 0 - Retorna ao menu principal                           \n");
        printf("\t\t\t\t    >>> ");
        scanf("%s", &nomeArquivo);

        if (nomeArquivo[0] == '1'){
            ArquivoParaString(stringHolder);
        }
        return;
    }

    strcat(stringHolder, " ");
    while (fgets(texto, 10000, fp) != NULL){
        strcat(stringHolder, texto);
    }
    strcat(stringHolder, " ");

    fclose(fp);

    system("CLS");
    printf("\t\t\t\t --------------------------------------------------------- \n");
    printf("\t\t\t\t               TEXTO INSERIDO COM SUCESSO!          \n");
    printf("\t\t\t\t --------------------------------------------------------- \n");
    printf("\t\t\t\t 0 - Retorna ao menu principal                           \n");
    printf("\t\t\t\t    >>> ");
    scanf("%s",&nomeArquivo);
    strcpy(nomeArquivo, "");
    return 0;

}


// CONTA O NUMERO DE PALAVRAS EM UM TEXTO
void ContaPalavras (const char *texto){
    char aux[30];
    if (TextoVazio(texto)){
        OTextoEstaVazio();
    } else {
        system("CLS");
        printf("\t\t\t\t --------------------------------------------------------- \n");
        printf("\t\t\t\t            O texto tem atualmente %d palavras          \n", NumeroDePalavras(texto));
        printf("\t\t\t\t                                                         \n");
        printf("\t\t\t\t 0 - Retorna ao menu principal                           \n");
        printf("\t\t\t\t --------------------------------------------------------- \n");
        printf("\t\t\t\t    >>> ");
        scanf("%s",&aux);
    }
}

// RETORNA O NUMERO DE PALAVRAS NO TEXTO ATUAL
int NumeroDePalavras(const char *texto){
    int numDePalavrasNoTexto = 0;

    for (int i = 0; texto[i] != '\0';i++)
    {
        if (texto[i] == ' ' && (texto[i+1] != ' ') && (texto[i+1] != '\0'))
            numDePalavrasNoTexto++;
    }

    return numDePalavrasNoTexto;
}

// RETORNA 1 SE O TEXTO ESTA VAZIO
int TextoVazio(const char *texto){
    if (strlen(texto) <= 1 ){
        return 1;
    } else{
        return 0;
    }
}

// PRINTA QUE O TEXTO ESTA VAZIO
void OTextoEstaVazio(){
    char aux[10];

    system("CLS");
    printf("\t\t\t\t --------------------------------------------------------- \n");
    printf("\t\t\t\t                    O texto esta vazio                    \n");
    printf("\t\t\t\t                                                         \n");
    printf("\t\t\t\t 0 - Retornar                           \n");
    printf("\t\t\t\t --------------------------------------------------------- \n");
    printf("\t\t\t\t    >>> ");
    scanf("%s",&aux);
}
