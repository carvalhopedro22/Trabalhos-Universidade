// -----------------------------------------
//             UFV - CAF
//      Trabalho Pratico I  - AEDS II
// -----------------------------------------
// Leonardo Alvarenga - leo-alvarenga - 3895
// Caio Rocha - CaioRocha-UFV e RockFall - 3892
// Pedro Carvalho carvalhopedro22 - 3877
// William Araujo WilliamAraujoSCdc - 3472
//___________________________________________


#ifndef TP1_AEDS2_TST_H
#define TP1_AEDS2_TST_H

#include "../assets/auxiliar.h"

#define MAX 50

typedef struct NO* PointerTST;

typedef struct NO{
    char letter;
    bool endOfString: true;
    PointerTST left, eq, right;
}No;
/*
// Funcao para inicializacao da TST
PointerTST* initializeTST(){

// Funcao para alocar e retornar um novo noh dinamicamente
PointerTST newNode(char info){

// Funcao recursiva para insercao de uma nova palavra na arvore trie TST
void insert(PointerTST *root, char *word){

// Funcao secundaria, executa o percurso transversal na arvore
void traversetst(PointerTST root, char *buffer, int depth){

// Funcao primaria, executa o percurso transversal na arvore chamando a funcao anterior
void TraverseTST(PointerTST root){

// Funcao de pesquisa
int searchTST(PointerTST root, char *word, int *comparacoes)

// Mostrar o contador e zera-o em seguida
void NumeroDeComparacoesTST(PointerTST raiz);

// Insere o texto na TST
void TSTInserirTexto(const char *texto, PointerTST **raiz);
*/
#endif //TP1_AEDS2_TST_H
