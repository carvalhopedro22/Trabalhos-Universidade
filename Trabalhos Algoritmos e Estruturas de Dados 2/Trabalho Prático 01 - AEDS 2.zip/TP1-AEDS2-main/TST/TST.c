// -----------------------------------------
//             UFV - CAF
//      Trabalho Pratico I  - AEDS II
// -----------------------------------------
// Leonardo Alvarenga - leo-alvarenga - 3895
// Caio Rocha - CaioRocha-UFV e RockFall - 3892
// Pedro Carvalho carvalhopedro22 - 3877
// William Araujo WilliamAraujoSCdc - 3472
//___________________________________________

#include "TST.h"

// VARIAVEIS GLOBAIS:
// -> compInsercaoTST, contador de comparações para TST
int compInsercaoTST = 0;

// Funcao para inicializacao da TST
PointerTST* initializeTST(){
    PointerTST *raiz;
    raiz = (PointerTST *)(malloc(sizeof(PointerTST)));
    *raiz = NULL;
    return raiz;
}

// Funcao para alocar e retornar um novo noh dinamicamente
PointerTST newNode(char info){
    PointerTST temp = (PointerTST)(malloc(sizeof(No)));
    temp->letter = info;
    temp->endOfString = true;
    temp->left = temp->eq = temp->right = NULL;

    return temp;
}

// Funcao recursiva para insercao de uma nova palavra na arvore trie TST
void insert(PointerTST *root, char *word){
    //Caso base: arvore vazia
    if(!(*root))
        *root = newNode(*word);

    if ((*word) < (*root)->letter){
        // Se o char atual é menor q o char da raiz,
        // insere ele a esquerda da raiz
        compInsercaoTST++;
        insert(&( (*root)->left ), word);
    }

    else if ((*word) > (*root)->letter){
        // Se o char atual da palavra é maior que o da raiz,
        // insere ele a direita da raiz
        compInsercaoTST += 2;
        insert(&( (*root)->right ), word);
    }
    else
    {
        compInsercaoTST += 3;
        // Se o char atual é igual ao da raiz, insere abaixo
        if (*(word+1)){
                compInsercaoTST++;
            // checa se o prox elemento existe
            // insere o prox elemento do vetor word
            insert(&((*root)->eq), word+1);
        }
        else{
            compInsercaoTST += 2;
            // ultimo char da palavra
            (*root)->endOfString = true;
        }
    }
    compInsercaoTST += 2; // COMPARACOES 3 E 4

}

// Funcao secundaria, executa o percurso transversal na arvore
void traversetst(PointerTST root, char *buffer, int depth){
    if (root)
    {
        // Primeiro acessa a subarvore a esquerda
        traversetst(root->left, buffer, depth);

        // guarda a info
        buffer[depth] = root->letter;
        // checa se é o fim
        if (root->endOfString)
        {
            // adiciona marcador de fim ao vetor
            buffer[depth+1] = '\0';
            // printa o fim
            printf( "\t\t\t\t%s\n", buffer);
        }

        // Depois acessa a subarvore no meio
        traversetst(root->eq, buffer, depth + 1);

        // Por fim acessa a subarvore a direita
        traversetst(root->right, buffer, depth);
    }
}

// Funcao primaria, executa o percurso transversal na arvore chamando a funcao anterior
void TraverseTST(PointerTST root){
    char buffer[MAX];
    traversetst(root, buffer, 0);
}

// Funcao de pesquisa
int searchTST(PointerTST root, char *word, int *comparacoes){
    // Caso base: arvore vazia
    if (!root)
        return 0;

    // Letra atual é menor q a letra da raiz
    if (*word < (root)->letter){
        (*comparacoes)++;
        // caminha pra esquerda
        return searchTST(root->left, word, comparacoes);
    }
        // Letra atual é maior q a letra da raiz
    else if (*word > (root)->letter){
        (*comparacoes)++;
        // caminha pra direita
        return searchTST(root->right, word, comparacoes);
    }
        // Letra atual é igual a letra da raiz
    else
    {
        // checa se letra atual é um marcador de fim de string
        if (*(word+1) == '\0'){
            (*comparacoes)++;
            return root->endOfString;
        }

        // continua a pesquisa
        return searchTST(root->eq, word+1, comparacoes);
    }
}

// Mostrar o contador e zera-o em seguida
void NumeroDeComparacoesTST(PointerTST raiz){
    printf("\n\t\t\t--> Numero total de comparacoes para insercao na TST: %d\n", compInsercaoTST);
    compInsercaoTST = 0;
}

// Insere o texto na TST
void TSTInserirTexto(const char *texto, PointerTST **raiz){

    // SE O TEXTO ESTA VAZIO, PRINTA E RETORNA
    if (TextoVazio(texto)){
        OTextoEstaVazio();
        return;
    }

    // Inicia a TST
    (*raiz) = initializeTST();



    // ---- Variaveis ----
    char palavra[50];
    char arrayDePalavras[10000][50];
    char aux[30];

    strcpy(palavra, "");

    // Flag que indica que estamos atualmente dentro de uma palavra
    int addingWord = 0, indexCurrWord = 0;

    // -------------- TIMER ------------------
    LARGE_INTEGER frequency;        // ticks per second
    LARGE_INTEGER t1, t2;           // ticks
    double elapsedTime;
    // get ticks per second
    QueryPerformanceFrequency(&frequency);
    // start timer
    QueryPerformanceCounter(&t1);
    // -------------- TIMER ------------------

    // LOOP PARA INDENTIFICAR AS PALAVRAS
    for (int i = 1; texto[i] != '\0';i++)
    {
        char currentChar[1];
        currentChar[0] = tolower(texto[i]);

        // IF acabamos de entrar em uma nova palavra
        if ((texto[i] != ' ' && texto[i-1] == ' ') || (texto[i] != '\n' && texto[i-1] == '\n')){
            addingWord = 1; // FLAG = 1
        }

        // ELSE IF chegamos no final de uma palavra
        else if (texto[i] == ' ' || texto[i] == '\n' ){
            addingWord = 0; // FLAG = 0
        }


        if (addingWord == 0){ // IF nao estamos em uma palavra -> Palavra completa
            // Adicionamos a palavra à arvore
            insert((*raiz), palavra);
            //strcpy(arrayDePalavras[indexCurrWord], palavra);
            //printf("Adicionado (%s): [%s]", palavra, arrayDePalavras[indexCurrWord]);
            //indexCurrWord++;
            strcpy(palavra, ""); // reseta palavra

        } else{ // ELSE estamos em uma palavra
            if (strcmp(currentChar, ".") != 0 && strcmp(currentChar, ",") != 0 && strcmp(currentChar, ";") != 0 && strcmp(currentChar, "|") != 0 ){
                strcat(palavra, currentChar); // ADD palavra

            }
        }
    }

    // stop timer
    QueryPerformanceCounter(&t2);
    // compute and print the elapsed time in millisec
    elapsedTime = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;

    system("CLS");
    printf("\t\t\t\t --------------------------------------------------------- \n");
    printf("\t\t\t\t                 TEXTO INSERIDO NA TST!          \n");
    printf("\t\t\t\t --------------------------------------------------------- \n");
    NumeroDeComparacoesTST(**raiz);
    printf("\t\t\t--> Tempo gasto na insercao da TST: %f\n", elapsedTime);
    printf("\n\n\t\t\t\t 0 - Retorna ao menu principal                           \n");
    printf("\t\t\t\t    >>> ");
    scanf("%s",&aux);
}
