// -----------------------------------------
//             UFV - CAF
//      Trabalho Pratico I  - AEDS II
// -----------------------------------------
// Leonardo Alvarenga - leo-alvarenga - 3895
// Caio Rocha - CaioRocha-UFV e RockFall - 3892
// Pedro Carvalho carvalhopedro22 - 3877
// William Araujo WilliamAraujoSCdc - 3472
//___________________________________________

#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include "assets/auxiliar.h"
#include "PATRICIA/PATRICIA.h"
#include "TST/TST.h"
/*
// Menu Principal
void imprimeMenu();

// Menus das Arvores
void EscolherArvore(const char *texto, PointerTST *raizTST, PointerPAT *raizPAT);

// PESQUISA NA TST
void PesquisaNaTST(PointerTST raiz);

// PESQUISA NA PATRICIA
void PesquisaNaPAT(PointerPAT raiz);

// TODO ADICIONA UMA PALAVRA AO TEXTO
void InserirPalavra(const char *palavraASerInserida, const char *texto);

// TODO REMOVE UMA PALAVRA DO TEXTO
void RemoverPalavra(const char *palavraASerRemovida);

// PRINTA NA TELA O TEXTO ATUAL
void PrintarTexto(const char *texto);


// TRANSFORMA UM .TXT EM UMA STRING
//void ArquivoParaString(const char *stringHolder);

// CONTA O NUMERO DE PALAVRAS EM UM TEXTO
void ContaPalavras (const char *texto);

// RETORNA O NUMERO DE PALAVRAS NO TEXTO ATUAL
int NumeroDePalavras(const char *texto);

// RETORNA 1 SE O TEXTO ESTA VAZIO
int TextoVazio(const char *texto);

// PRINTA QUE O TEXTO ESTA VAZIO
void OTextoEstaVazio();
*/
#endif // MENU_H_INCLUDED
