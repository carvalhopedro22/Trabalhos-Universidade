//
// -----------------------------------------
//             UFV - CAF
//      Trabalho Pratico I  - AEDS II
// -----------------------------------------
// Leonardo Alvarenga - leo-alvarenga - 3895
// Caio Rocha - CaioRocha-UFV e RockFall - 3892
// Pedro Carvalho carvalhopedro22 - 3877
// William Araujo WilliamAraujoSCdc - 3472
//___________________________________________

// Arquivo criado a fim de organizar importações, funções e variáveis
// em múltiplos arquivos

#ifndef TP1_AEDS2_AUXILIAR_H
#define TP1_AEDS2_AUXILIAR_H

// Inclusoes de bibliotecas externas
// (sao necessarias em pelo menos um dos demais arquivos do projeto)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/time.h>
#include <windows.h>

typedef enum{
    false, true
} bool;

// Isso aqui tava na deficao da PATRICIA original mas n tava sendo usado
// resolvi deixar pra n causar nenhum problema
typedef enum{
    Interno, Externo
} NodeType;

#endif //TP1_AEDS2_AUXILIAR_H
