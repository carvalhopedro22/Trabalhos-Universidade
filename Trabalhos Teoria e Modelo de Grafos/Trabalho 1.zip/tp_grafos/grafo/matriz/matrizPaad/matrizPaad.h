//
// Created by vitor on 2/28/21.
//
#include "../grafoMatriz.h"
#include "../../../paad/paad.h"


#ifndef TP_C_MATRIZPAAD_H
#define TP_C_MATRIZPAAD_H


int paadToMatriz(GrafoMatriz *grafo, Paad *paad);

int matrizToPaad(GrafoMatriz *grafo, Paad *paad);


#endif //TP_C_MATRIZPAAD_H
