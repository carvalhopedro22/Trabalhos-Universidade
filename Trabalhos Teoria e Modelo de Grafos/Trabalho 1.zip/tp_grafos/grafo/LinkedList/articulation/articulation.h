//
// Created by vitor on 3/28/21.
//

#include "../grafoLinkedList.h"
#include "../conexo/conexo.h"

#ifndef TP_C_ARTICULATION_H
#define TP_C_ARTICULATION_H

int articulationLinked(GrafoLinked *grafo);

#endif //TP_C_ARTICULATION_H
