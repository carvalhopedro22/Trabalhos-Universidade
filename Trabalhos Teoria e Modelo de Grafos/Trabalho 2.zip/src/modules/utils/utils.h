#include "../../defines.h"
#ifndef TP_C_UTILS_H
#define TP_C_UTILS_H

typedef struct {
    int linha;
    int coluna;
    float peso;
} fileStruct;

void print_grafos();

int get_int();

#endif //TP_C_UTILS_H
