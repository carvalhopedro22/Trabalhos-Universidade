#include "../../matriz/grafoMatriz.h"
#include "../conexo/conexo.h"

#ifndef TP_C_ARTICULACAO_H
#define TP_C_ARTICULACAO_H

//ARTICULAÇÃO
void grafoArticulacao(GrafoMatriz G, int vertice);

#endif //TP_C_ARTICULACAO_H
