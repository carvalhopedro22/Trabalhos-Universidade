## CSU11: Verificar Autenticidade de Gema

**Sumário:** O Usuário utiliza o sistema para se certificar da autenticidade de uma gema.

**Ator primário:** Usuário.

### Fluxo Principal:
1. O Usuário está visualizando os dados de uma gema de sua coleção.
2. O Usuário solicita que a autenticidade daquela gema seja verificada.
3. O sistema usa a chave pública da Forja para verificar a assinatura associada àquela gema, e informa ao usuário se os dados são autênticos.
4. O sistema encerra o caso de uso.
