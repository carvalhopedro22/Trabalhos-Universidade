## CSU12: Apagar Gema

**Sumário:** O Usuário apaga uma gema de sua coleção.

**Ator primário:** Usuário.

### Fluxo Principal:
1. O Usuário está visualizando os dados de uma gema de sua coleção.
2. O Usuário solicita que aquela gema seja apagada.
3. O sistema apaga os dados daquela gema.
4. O sistema encerra o caso de uso.

**Pós-condições:** a gema selecionada foi apagada da coleção do Usuário.
