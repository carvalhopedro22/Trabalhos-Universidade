CREATE TABLE IF NOT EXISTS quota (
  id TEXT NOT NULL,
  last_request_at TEXT NOT NULL,
  PRIMARY KEY (id)
);
