
class InvalidUsernameError(Exception): pass
class UsernameTakenError(Exception): pass
class QuotaError(Exception): pass
class UnknownError(Exception): pass
class InvalidGemError(Exception): pass