## CSU03: Visualizar Gema

**Sumário:** O Usuário visualiza os dados de uma gema específica de sua coleção.

**Ator primário:** Usuário.

### Fluxo Principal:
1. O sistema apresenta a tela principal ao usuário.
2. O Usuário acessa a opção de visualizar sua coleção de gemas.
3. O sistema apresenta os dados de todas as gemas que o Usuário possui.
4. O Usuário seleciona uma gema.
5. O sistema exibe todos os dados daquela gema.
6. O sistema encerra o caso de uso.
